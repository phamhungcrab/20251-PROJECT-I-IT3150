"""
run_colab.py

File này là “entry-point” (điểm bắt đầu) để chạy dự án dễ dàng trên Google Colab.

Ý tưởng:
- Trong project ML thường có nhiều file (config, build features, train, evaluate...)
- Người mới chỉ cần chạy 1 file duy nhất để train toàn bộ pipeline
- File này gọi Config + run_training(cfg)

Cách dùng (trong Colab):
1) Mount Google Drive (nếu dữ liệu nằm trong Drive) và kiểm tra đường dẫn data_dir.
2) Chạy lệnh:
   !python run_colab.py

Nếu muốn bật Optuna tune (tối ưu tham số LightGBM):
- bật cfg.lgbm_tune = True
- tăng cfg.lgbm_trials để thử nhiều hơn
- lưu ý: cần cài optuna (pip install optuna)
"""

from src.config import Config
# Import lớp Config: chứa tất cả cấu hình (đường dẫn dữ liệu, tỉ lệ split, tham số model...)

from src.train import run_training
# Import hàm run_training: pipeline train chính của dự án


def main():
    """
    Hàm main() giúp tổ chức code rõ ràng hơn.

    Thói quen tốt:
    - Tất cả thao tác chạy chính nằm trong main()
    - File chạy trực tiếp sẽ gọi main() ở cuối
    """

    # 1) Tạo config mặc định
    cfg = Config()

    # 2) Nếu dữ liệu của bạn nằm ở chỗ khác, sửa đường dẫn ở đây.
    # Ví dụ trên Colab thường là:
    # /content/drive/MyDrive/...
    #
    # Lưu ý:
    # - Muốn dùng Path thì phải import Path: from pathlib import Path
    # - Nếu bạn chỉ gán string (cfg.data_dir = "...") thì trong code khác có thể kỳ vọng Path,
    #   vì vậy nên dùng Path để thống nhất kiểu dữ liệu.
    #
    # cfg.data_dir = Path("/content/drive/MyDrive/malware")

    # 3) (Tuỳ chọn) Bật tuning LightGBM bằng Optuna
    #
    # - cfg.lgbm_tune = True: bật chế độ tune
    # - cfg.lgbm_trials: số lần thử (trial) - nhiều trial hơn -> có thể tốt hơn nhưng tốn thời gian hơn
    #
    # cfg.lgbm_tune = True
    # cfg.lgbm_trials = 50

    # 4) Chạy pipeline training
    # Hàm run_training sẽ:
    # - load/build dataset
    # - split train/val/test
    # - train model candidates
    # - chọn best theo val metric
    # - refit train+val
    # - evaluate test
    # - lưu model + report
    run_training(cfg)


if __name__ == "__main__":
    """
    Khối này chỉ chạy khi bạn chạy file trực tiếp:
        python run_colab.py

    Nếu file này được import từ file khác, khối này sẽ không chạy.
    """
    main()
