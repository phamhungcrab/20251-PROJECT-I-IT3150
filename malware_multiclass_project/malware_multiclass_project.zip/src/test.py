"""
test.py - File test đơn giản để kiểm tra căn chỉnh confusion matrix

Chạy: python -m malware_multiclass_project.src.test
Hoặc: python malware_multiclass_project/src/test.py
"""

import numpy as np

def _format_cm(cm: np.ndarray, classes: list, float_fmt="{:0.0f}") -> str:
    """
    Format confusion matrix thành bảng chữ đẹp trong log.
    """
    # Độ rộng cố định cho mỗi cột giá trị
    col_width = 8

    # Tính độ rộng tối đa cho tên lớp (để căn chỉnh row label)
    max_class_len = max(len(str(c)[:col_width]) for c in classes)
    # Row label format: "true <class>" - tổng độ rộng = 5 ("true ") + max_class_len
    row_label_width = 5 + max_class_len

    # Tạo header: phần label trống + tên các lớp (predicted)
    # Header label: căn phải với row_label_width để khớp với data rows
    header_label = f"{'pred→':>{row_label_width}}"
    header_cols = " ".join([f"{str(c)[:col_width]:>{col_width}}" for c in classes])
    header = f"{header_label} {header_cols}"

    # Separator line
    separator = "-" * len(header)

    lines = [header, separator]
    for i, row in enumerate(cm):
        # Row label: "true <class>" căn phải với row_label_width
        class_name = str(classes[i])[:col_width]
        row_label = f"{'true ' + class_name:>{row_label_width}}"
        # Giá trị các cột - có space giữa các cột
        row_values = " ".join([f"{float_fmt.format(x):>{col_width}}" for x in row])
        lines.append(f"{row_label} {row_values}")

    return "\n".join(lines)


if __name__ == "__main__":
    # ===== Test 1: Classes là số (0-6) =====
    print("=" * 60)
    print("TEST 1: Classes là số (0, 1, 2, 3, 4, 5, 6)")
    print("=" * 60)

    classes_numeric = ["0", "1", "2", "3", "4", "5", "6"]

    # Tạo confusion matrix giả (giống screenshot)
    cm_counts = np.array([
        [353,   1,   2,  10,   3,   3,   3],
        [  0, 939,   0,  14,  35,   9,   7],
        [  0,   0, 925,   1,   1,   0,   0],
        [ 12,   8,   1, 837,  16,  67,  50],
        [  1,  33,   2,  18, 922,  16,  23],
        [  0,   2,   2,  19,   6, 674, 141],
        [  0,   1,   0,  10,   9,  93, 627],
    ])

    print("\nConfusion matrix (counts):")
    print(_format_cm(cm_counts, classes_numeric))

    # Normalized version
    cmn = cm_counts.astype(np.float64) / np.maximum(1, cm_counts.sum(axis=1, keepdims=True))
    print("\nConfusion matrix (row-normalized):")
    print(_format_cm(cmn, classes_numeric, float_fmt="{:0.2f}"))

    # ===== Test 2: Classes là tên malware =====
    print("\n" + "=" * 60)
    print("TEST 2: Classes là tên malware families")
    print("=" * 60)

    classes_names = ["Benign", "RedLine", "Download", "RAT", "Banking", "Snake", "Spyware"]

    print("\nConfusion matrix (counts):")
    print(_format_cm(cm_counts, classes_names))

    print("\nConfusion matrix (row-normalized):")
    print(_format_cm(cmn, classes_names, float_fmt="{:0.2f}"))

    # ===== Test 3: Classes với tên dài =====
    print("\n" + "=" * 60)
    print("TEST 3: Classes với tên dài (bị cắt 8 ký tự)")
    print("=" * 60)

    classes_long = ["BenignSoftware", "RedLineStealer", "Downloader", "RemoteAccessTrojan",
                    "BankingTrojan", "SnakeKeyLogger", "SpywareAgent"]

    print("\nConfusion matrix (counts):")
    print(_format_cm(cm_counts, classes_long))

    print("\n✅ Tests completed!")
