"""
config.py

File này định nghĩa lớp Config (cấu hình) cho dự án Malware Detection.
Mục tiêu: gom tất cả tham số (đường dẫn dữ liệu, tỉ lệ chia tập, tham số model, cache...)
vào một nơi để:
- dễ chỉnh sửa
- dễ tái sử dụng
- dễ ghi lại cấu hình khi báo cáo / chạy lại thí nghiệm
"""

from __future__ import annotations
# ↑ Cho phép dùng type hint dưới dạng "chuỗi" một cách linh hoạt hơn,
#   và giúp forward-reference (tham chiếu kiểu chưa được định nghĩa) hoạt động tốt.
#   Với Python 3.11+ thì thường ít cần, nhưng dùng vẫn ok.

from dataclasses import dataclass, asdict
# dataclass: giúp viết class chứa dữ liệu (config) gọn hơn:
# - tự sinh __init__, __repr__, so sánh, ...
# asdict: chuyển dataclass -> dict (rất tiện để dump JSON/log)

from pathlib import Path
# Path: làm việc với đường dẫn file/folder theo kiểu "object" (dễ + an toàn hơn string),
# dùng được trên nhiều OS (Windows/Linux/Colab)

from typing import Dict, Any
# Dict[str, Any]: kiểu dữ liệu "dictionary" (key là string, value có thể là bất kỳ)


@dataclass
class Config:
    """
    Config = "bảng cấu hình" cho toàn bộ dự án.

    Tư duy:
    - Thay vì hard-code rải rác trong nhiều file, ta gom cấu hình về 1 chỗ.
    - Khi chạy nhiều thí nghiệm (thay model / thay split / thay tham số),
      bạn chỉ cần sửa Config.

    Gợi ý cách dùng trong notebook / script:
        cfg = Config()
        cfg.ensure_dirs()
        print(cfg.data_dir)
    """

    # ==========================================================
    # 1) Paths (đường dẫn)
    # ==========================================================

    # data_dir: thư mục chứa dữ liệu thô (4 file CSV)
    # Ví dụ trên Google Colab thường mount Google Drive vào /content/drive/...
    data_dir: Path = Path("/content/drive/MyDrive/malware")

    # cache_dir: nơi lưu dữ liệu cache (vd parquet) để đọc nhanh lần sau
    cache_dir: Path = Path("/content/drive/MyDrive/malware/cache")

    # out_dir: nơi lưu outputs: model đã train, report, log, ...
    out_dir: Path = Path("/content/drive/MyDrive/malware/outputs")

    # ==========================================================
    # 2) Filenames (tên file CSV)
    # ==========================================================

    # 4 feature sets của dataset (mỗi file là một loại đặc trưng)
    dlls_csv: str = "DLLs_Imported.csv"    # danh sách DLL import (dạng categorical/binary)
    api_csv: str = "API_Functions.csv"     # danh sách API function call (categorical/binary)
    hdr_csv: str = "PE_Header.csv"         # 52 fields header (numerical)
    sect_csv: str = "PE_Section.csv"       # features theo PE sections (numerical)

    # ==========================================================
    # 3) Split (chia dữ liệu train/val/test)
    # ==========================================================

    # random_state: "hạt giống" random để kết quả chia dữ liệu reproducible (chạy lại ra y như cũ)
    random_state: int = 42

    # test_size: tỷ lệ test trên toàn bộ dữ liệu.
    # Ví dụ 0.20 nghĩa là 20% dữ liệu để đánh giá cuối cùng (test).
    test_size: float = 0.20

    # val_size: tỷ lệ validation lấy từ phần còn lại sau khi tách test.
    # Cẩn thận: comment gốc "phần của (train+val)" -> nghĩa là:
    # - Đầu tiên tách test ra khỏi toàn bộ
    # - Phần còn lại gọi là trainval
    # - Từ trainval, lấy ra val_size để làm validation
    # Ví dụ:
    #   test=20% toàn bộ
    #   còn lại trainval=80%
    #   val = 20% của trainval = 16% toàn bộ
    #   train = 64% toàn bộ
    val_size: float = 0.20

    # ==========================================================
    # 4) IO (đọc/ghi dữ liệu)
    # ==========================================================

    # use_cache: bật/tắt cache.
    # - True: nếu đã có cache thì đọc cache (nhanh hơn nhiều so với đọc CSV + xử lý lại)
    # - False: luôn xử lý lại từ CSV (chậm nhưng đảm bảo mới nhất)
    use_cache: bool = True

    # chunksize: khi đọc CSV lớn, đọc theo "chunk" để tránh tốn RAM.
    # 5000 nghĩa là mỗi lần đọc 5000 dòng.
    chunksize: int = 5000

    # Log dataset observation summaries (column type grouping) when loading raw CSVs.
    log_data_observation: bool = True

    # Max column names to list per group in the observation log (0 = don't list).
    log_data_observation_max_cols: int = 0

    # ==========================================================
    # 5) Training (cấu hình train chung)
    # ==========================================================

    # n_jobs: số core CPU dùng cho các bước có hỗ trợ parallel.
    # -1 = dùng tất cả core (thường nhanh hơn).
    n_jobs: int = -1

    # metric_for_model_select: metric dùng để chọn mô hình tốt nhất.
    # - "f1_macro": phù hợp khi nhiều lớp/ mất cân bằng lớp (tính F1 từng lớp rồi lấy trung bình).
    # - "accuracy": dễ hiểu nhưng có thể đánh lừa nếu data imbalance.
    metric_for_model_select: str = "f1_macro"

    # ==========================================================
    # 6) Logistic Regression (ElasticNet) - Grid search
    # ==========================================================

    # Logistic Regression thường có tham số regularization:
    # - C: mức "ngược" của regularization
    #   C nhỏ -> regularization mạnh -> model đơn giản hơn -> giảm overfitting (nhưng có thể underfit)
    #   C lớn -> regularization yếu -> model linh hoạt hơn
    # logreg_C_grid = (0.1, 0.3, 1.0, 3.0, 10.0)
    logreg_C_grid = [0.1, 0.5, 3.0]  # Updated: focus on smaller C (stronger regularization)
    # l1_ratio (ElasticNet): trộn giữa L1 và L2:
    # - 0.0 -> thuần L2 (Ridge)
    # - 1.0 -> thuần L1 (Lasso) (tạo sparse weights, feature selection tự nhiên)
    # - ở giữa -> kết hợp cả 2
    # logreg_l1_ratio_grid = (0.0, 0.25, 0.5, 0.75, 1.0)
    logreg_l1_ratio_grid = [0.0, 0.5]    # Scan extremes + 1 mix point
    # max_iter: số vòng lặp tối đa cho solver tối ưu.
    # Nếu dữ liệu nhiều/regularization khó hội tụ, cần tăng max_iter.
    logreg_max_iter: int = 2000
    # Tolerance for stopping criteria (default 1e-4). Relaxing to 1e-3 speeds up convergence.
    logreg_tol: float = 1e-3

    # ==========================================================
    # 7) LightGBM
    # ==========================================================

    # use_lightgbm: bật/tắt dùng LightGBM trong pipeline.
    use_lightgbm: bool = True

    # lgbm_num_boost_round: số cây tối đa (upper bound) trong boosting.
    # LightGBM sẽ thêm cây dần dần để giảm loss.
    lgbm_num_boost_round: int = 5000

    # lgbm_early_stopping_rounds:
    # Nếu trong N vòng liên tiếp validation metric không cải thiện -> dừng sớm.
    # Mục tiêu:
    # - tránh overfitting
    # - tiết kiệm thời gian
    lgbm_early_stopping_rounds: int = 200

    # ==========================================================
    # 8) LightGBM tuning (random search / optuna)
    # ==========================================================

    # lgbm_tune: bật/tắt việc tune tham số (tốn thời gian hơn nhưng có thể tăng hiệu năng)
    lgbm_tune: bool = True

    # lgbm_trials: số lần thử (trial) nếu tune bằng random search / optuna.
    lgbm_trials: int = 30

    # ==========================================================
    # 9) Dataset caching (sparse)
    # ==========================================================

    # Với đặc trưng dạng "DLL/API xuất hiện hay không", dữ liệu thường rất thưa (sparse):
    # hầu hết cột = 0, chỉ một ít cột = 1
    # Lưu dạng sparse (.npz) sẽ:
    # - tiết kiệm dung lượng
    # - load nhanh
    processed_dirname: str = "processed"

    # Tên file cache sau khi xử lý:
    processed_X_name: str = "X_all.npz"              # ma trận đặc trưng (sparse matrix)
    processed_y_name: str = "y_all.npy"              # nhãn (labels)
    processed_sha_name: str = "sha256_all.npy"       # id mẫu (SHA256)
    processed_feat_name: str = "feature_names.json"  # danh sách tên feature theo cột
    processed_classes_name: str = "classes.json"     # mapping lớp (nếu multi-class)

    # ==========================================================
    # 10) Helpers: tạo thư mục / chuyển config sang dict
    # ==========================================================

    def ensure_dirs(self) -> None:
        """
        Tạo các thư mục cần thiết nếu chưa tồn tại.

        Ý nghĩa:
        - Khi chạy lần đầu, các folder có thể chưa có.
        - mkdir(..., exist_ok=True) giúp không bị lỗi nếu folder đã tồn tại.
        """
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.out_dir.mkdir(parents=True, exist_ok=True)

        # Tách outputs theo mục đích để project sạch:
        (self.out_dir / "models").mkdir(parents=True, exist_ok=True)   # lưu model đã train
        (self.out_dir / "reports").mkdir(parents=True, exist_ok=True)  # lưu báo cáo/metrics
        (self.out_dir / "logs").mkdir(parents=True, exist_ok=True)     # log chạy

        # Thư mục chứa dữ liệu đã xử lý (processed) đặt trong data_dir
        (self.data_dir / self.processed_dirname).mkdir(parents=True, exist_ok=True)

    def to_dict(self) -> Dict[str, Any]:
        """
        Chuyển Config (dataclass) thành dict để:
        - in ra log
        - lưu ra JSON
        - ghi vào report cho reproducibility

        Lưu ý: Path không JSON-serializable tốt, nên ta convert Path -> str.
        """
        d = asdict(self)

        # Path -> str để dễ dump json
        d["data_dir"] = str(self.data_dir)
        d["cache_dir"] = str(self.cache_dir)
        d["out_dir"] = str(self.out_dir)
        return d
