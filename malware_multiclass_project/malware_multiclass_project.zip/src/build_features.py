from __future__ import annotations
# ^ Cho phép dùng type hint “trỏ tới chính class/kiểu chưa được định nghĩa ở phía trên”
#   (ví dụ: Optional[Tuple[...]] với các kiểu khai báo muộn) mà không cần đặt trong dấu nháy.
#   Trong Python mới, điều này giúp type hints linh hoạt và tránh lỗi forward-reference.

from pathlib import Path
# ^ Path: thao tác đường dẫn file/folder theo kiểu hướng đối tượng, portable hơn so với string.

from typing import List, Tuple, Dict, Optional
# ^ Type hints:
#   - List[T]: danh sách phần tử kiểu T
#   - Tuple[A,B,...]: bộ (tuple) gồm nhiều phần tử kiểu xác định
#   - Dict[K,V]: dict key kiểu K, value kiểu V
#   - Optional[T]: trả về T hoặc None

import numpy as np
import pandas as pd
import scipy.sparse as sp
# ^ sp: SciPy sparse, dùng cho ma trận thưa (csr_matrix, hstack, save_npz/load_npz...)

from .config import Config
# ^ Import Config (thường là dataclass) chứa các tham số/đường dẫn của pipeline.

from .utils import human_bytes, df_memory_bytes, sparse_memory_bytes, dump_json
# ^ Các hàm tiện ích:
#   - human_bytes: đổi số byte sang chuỗi “MB/GB” dễ đọc
#   - df_memory_bytes: ước tính bộ nhớ DataFrame
#   - sparse_memory_bytes: ước tính bộ nhớ sparse matrix

REQ_COLS = ("sha256", "type")
# ^ Bộ cột bắt buộc phải có trong mỗi file đặc trưng:
#   - sha256: định danh mẫu
#   - type: nhãn (family/benign/malware...)


def _require_cols(df: pd.DataFrame, name: str) -> None:
    # Kiểm tra DataFrame có đủ các cột bắt buộc (sha256, type) hay không.
    cols = set(df.columns)
    missing = [c for c in REQ_COLS if c not in cols]
    if missing:
        # Nếu thiếu, raise lỗi và show 10 cột đầu để debug nhanh.
        raise ValueError(f"[{name}] Missing required columns: {missing}. Available: {list(df.columns)[:10]}...")


def _drop_duplicates_by_sha(df: pd.DataFrame, name: str, logger=None) -> pd.DataFrame:
    # Phân tích kỹ hơn về các dòng trùng lặp trước khi drop
    before = len(df)

    # Tìm các dòng bị trùng SHA
    dups = df[df.duplicated(subset=["sha256"], keep=False)]

    # Nếu có trùng lặp
    if not dups.empty and logger:
        n_dups = len(dups)
        n_unique_sha_in_dups = dups["sha256"].nunique()
        logger.warning(f"[{name}] Found {n_dups} duplicate rows (from {n_unique_sha_in_dups} unique SHAs). Analysis:")

        # Kiểm tra xem trùng SHA có đồng nghĩa với trùng toàn bộ nội dung không?
        # Group by SHA và đếm số lượng dòng unique trong nhóm đó
        inconsistent_shas = []
        for s, group in dups.groupby("sha256"):
            # drop_duplicates() trên group xem còn lại mấy dòng
            # Nếu còn > 1 dòng -> Chứng tỏ cùng SHA nhưng nội dung khác nhau
            if len(group.drop_duplicates()) > 1:
                inconsistent_shas.append(s)

        if inconsistent_shas:
            logger.error(f"[{name}] CRITICAL: {len(inconsistent_shas)} SHAs have CONTRADICTORY features/labels!")

            # Show detailed diff for the first few inconsistent examples
            for s in inconsistent_shas[:3]:
                group = dups[dups["sha256"] == s]
                diff_cols = []
                for col in group.columns:
                    if group[col].nunique() > 1:
                        vals = group[col].unique()
                        diff_cols.append(f"{col}: {vals}")

                logger.error(f"[{name}]   --> SHA {s} conflicts in: {'; '.join(diff_cols)}")

            logger.error(f"[{name}]   (Risky drop: keeping first occurrence by default)")
        else:
            logger.info(f"[{name}] SAFE: All duplicates are identical rows. Safe to drop.")

    # Thực hiện drop
    df2 = df.drop_duplicates(subset=["sha256"], keep="first").copy()
    after = len(df2)

    if logger and after != before:
        logger.warning(f"[{name}] Dropped {before-after} redundant rows.")
    return df2


def _prefix_features(df: pd.DataFrame, prefix: str) -> pd.DataFrame:
    """
    Prefix tất cả feature columns để tránh trùng tên khi stack.

    Ví dụ:
      - Cột "size" ở hdr và sect có thể trùng nhau -> đổi thành "hdr__size" và "sect__size"
    """
    feat_cols = [c for c in df.columns if c not in ("sha256", "type")]
    rename = {c: f"{prefix}__{c}" for c in feat_cols}
    return df.rename(columns=rename)


def align_intersection_sha(
    dlls: pd.DataFrame,
    api: pd.DataFrame,
    hdr: pd.DataFrame,
    sect: pd.DataFrame,
    logger=None
) -> List[str]:
    """
    Lấy intersection của sha256 giữa 4 file để đảm bảo mỗi sample có đủ 4 nhóm feature.

    Ý nghĩa:
      - Nếu một sha chỉ xuất hiện ở 3/4 file thì sample đó thiếu feature -> loại bỏ để đồng bộ.
      - Kết quả trả về là danh sách sha theo thứ tự cố định (sorted) dùng để align rows.
    """
    s1 = set(dlls["sha256"].astype(str))
    s2 = set(api["sha256"].astype(str))
    s3 = set(hdr["sha256"].astype(str))
    s4 = set(sect["sha256"].astype(str))
    inter = s1 & s2 & s3 & s4  # giao của 4 tập sha

    if logger:
        # Báo cáo số lượng sha ở mỗi file và số lượng giao nhau cuối cùng.
        logger.info(f"sha256 counts: dlls={len(s1):,} api={len(s2):,} hdr={len(s3):,} sect={len(s4):,}")
        logger.info(f"intersection sha256 = {len(inter):,} samples (will be used).")

        # report dropped: các sha có trong từng file nhưng bị loại vì không đủ bộ 4 nhóm (không thuộc intersection)
        logger.info(f"Dropped samples (not in intersection):")
        logger.info(f"  - dlls dropped: {len(s1 - inter):,} (had {len(s1):,})")
        logger.info(f"  - api  dropped: {len(s2 - inter):,} (had {len(s2):,})")
        logger.info(f"  - hdr  dropped: {len(s3 - inter):,} (had {len(s3):,})")
        logger.info(f"  - sect dropped: {len(s4 - inter):,} (had {len(s4):,})")

    # Sắp xếp để có thứ tự ổn định, reproducible (cùng input -> cùng order).
    sha_order = sorted(inter)
    return sha_order


def build_sparse_Xy(
    dlls: pd.DataFrame,
    api: pd.DataFrame,
    hdr: pd.DataFrame,
    sect: pd.DataFrame,
    logger=None
) -> Tuple[sp.csr_matrix, np.ndarray, np.ndarray, List[str]]:
    """
    Align theo sha256 intersection và build:
      - X: scipy CSR sparse matrix (features)
      - y: nhãn (string) theo thứ tự sha
      - sha: mảng sha256 theo thứ tự
      - feature_names: list tên feature theo thứ tự cột X

    Lưu ý:
      - Hàm này chỉ “lắp ghép dữ liệu” + chuyển sang sparse.
      - Chưa thực hiện train/val/test split ở đây.
    """
    # 1) Verify input schema: bắt buộc phải có sha256 và type
    _require_cols(dlls, "dlls")
    _require_cols(api, "api")
    _require_cols(hdr, "hdr")
    _require_cols(sect, "sect")

    # 2) Chuẩn hoá dtype sha256 thành string để set/merge ổn định (tránh mixed types)
    for df in (dlls, api, hdr, sect):
        df["sha256"] = df["sha256"].astype(str)

    # 3) Drop duplicates theo sha256 để mỗi sample chỉ có 1 dòng trong từng file
    dlls = _drop_duplicates_by_sha(dlls, "dlls", logger)
    api = _drop_duplicates_by_sha(api, "api", logger)
    hdr = _drop_duplicates_by_sha(hdr, "hdr", logger)
    sect = _drop_duplicates_by_sha(sect, "sect", logger)

    # 4) Lấy giao sha giữa 4 file => chỉ dùng các sample đủ 4 nhóm feature
    sha_order = align_intersection_sha(dlls, api, hdr, sect, logger)
    sha_arr = np.array(sha_order, dtype=object)
    # ^ dtype=object vì sha256 là string, numpy thường lưu string/objects kiểu này.

    # 5) Prefix tên feature để tránh trùng cột khi hstack 4 nhóm
    dlls = _prefix_features(dlls, "dlls")
    api = _prefix_features(api, "api")
    hdr = _prefix_features(hdr, "hdr")
    sect = _prefix_features(sect, "sect")

    # 6) Align rows theo sha_order: đảm bảo 4 DataFrame cùng thứ tự hàng (cùng sha cùng index)
    def _align(df: pd.DataFrame, name: str) -> pd.DataFrame:
        df = df.set_index("sha256", drop=False)
        # loc theo sha_order (đảm bảo thứ tự). Nếu thiếu sha sẽ lỗi, nhưng vì đã lấy intersection nên an toàn.
        aligned = df.loc[sha_order]
        aligned = aligned.reset_index(drop=True)
        if logger:
            logger.info(f"Aligned {name}: shape={aligned.shape}, mem={human_bytes(df_memory_bytes(aligned))}")
        return aligned

    dlls_a = _align(dlls, "dlls")
    api_a = _align(api, "api")
    hdr_a = _align(hdr, "hdr")
    sect_a = _align(sect, "sect")

    # --- Label consistency check ---
    # 7) Vì mỗi file đều có cột type, ta kiểm tra xem nhãn có bị lệch giữa các file cho cùng sha không.
    y_cols = [
        dlls_a["type"].astype(str).to_numpy(),
        api_a["type"].astype(str).to_numpy(),
        hdr_a["type"].astype(str).to_numpy(),
        sect_a["type"].astype(str).to_numpy(),
    ]
    y_stack = np.vstack(y_cols).T  # shape (n,4): mỗi hàng là 4 nhãn ứng với 4 file cho cùng sample.

    # 8) Nếu có mismatch, chọn nhãn theo majority vote (mode) để “hợp nhất” nhãn.
    y_mode = []
    mismatch_rows = 0
    for row in y_stack:
        vals, cnts = np.unique(row, return_counts=True)
        best = vals[np.argmax(cnts)]
        y_mode.append(best)
        if len(vals) > 1:
            mismatch_rows += 1
    y = np.array(y_mode, dtype=object)

    if logger:
        logger.info(f"Label mismatch rows across files: {mismatch_rows:,} / {len(y):,}")
        if mismatch_rows > 0:
            # show vài ví dụ mismatch để bạn kiểm tra dữ liệu nguồn
            idxs = np.where(np.apply_along_axis(lambda r: len(set(r))>1, 1, y_stack))[0][:5]
            for i in idxs:
                logger.warning(f"  mismatch example sha={sha_arr[i]} labels={y_stack[i].tolist()} -> using '{y[i]}'")

    # --- Build sparse X ---
    # 9) Chuyển từng nhóm feature (dlls/api/hdr/sect) thành csr_matrix.
    #    Với dlls/api thường là one-hot/binary -> rất thưa; hdr/sect là numeric -> có thể ít thưa hơn.
    def _to_csr_features(df: pd.DataFrame, name: str) -> Tuple[sp.csr_matrix, List[str]]:
        feat_cols = [c for c in df.columns if c not in ("sha256", "type")]
        if logger:
            logger.info(f"{name}: Excluded 'sha256' and 'type'. Using {len(feat_cols):,} feature columns.")
        # Lấy ma trận dense (numpy) từ các cột feature.
        # copy=False để tránh copy dữ liệu nếu có thể.
        X_dense = df[feat_cols].to_numpy(copy=False)

        # csr_matrix(...) sẽ tạo sparse từ dense:
        # - Các giá trị 0 sẽ không lưu, các giá trị khác 0 mới lưu (nnz = number of non-zeros).
        X = sp.csr_matrix(X_dense)

        # Cast float32 để giảm RAM (float64 thường gấp đôi).
        X = X.astype(np.float32)

        if logger:
            nnz = X.nnz
            total_elements = X.shape[0] * X.shape[1]
            density = nnz / total_elements if total_elements > 0 else 0
            sparsity = 1 - density
            logger.info(
                f"{name}: features={len(feat_cols):,} X.shape={X.shape} nnz={nnz:,} "
                f"density={density:.4%} sparsity={sparsity:.4%} mem={human_bytes(sparse_memory_bytes(X))}"
            )
        return X, feat_cols

    # 10) Với hdr/sect: ép kiểu numeric và fill NaN bằng 0.
    #     Lưu ý: fill bằng hằng số 0 là thao tác “constant imputation” (không dùng thống kê toàn dataset),
    #     nên bản chất không “leak” mean/std từ test (đỡ rủi ro leakage nếu sau này bạn split đúng cách).
    for df_name, df in (("hdr", hdr_a), ("sect", sect_a)):
        feat_cols = [c for c in df.columns if c not in ("sha256", "type")]
        for c in feat_cols:
            if not pd.api.types.is_numeric_dtype(df[c]):
                # to_numeric(errors="coerce"): giá trị không parse được thành số -> NaN
                df[c] = pd.to_numeric(df[c], errors="coerce")
        # Fill NaN -> 0 để tránh sparse build gặp NaN và để model xử lý nhất quán.
        df[feat_cols] = df[feat_cols].fillna(0)

    # 11) Build sparse matrix cho từng nhóm
    X_dlls, fn_dlls = _to_csr_features(dlls_a, "DLLs")
    X_api, fn_api = _to_csr_features(api_a, "APIs")
    X_hdr, fn_hdr = _to_csr_features(hdr_a, "Header")
    X_sect, fn_sect = _to_csr_features(sect_a, "Section")

    # 12) Nối theo chiều cột (feature axis): X = [dlls | api | hdr | sect]
    X = sp.hstack([X_dlls, X_api, X_hdr, X_sect], format="csr").astype(np.float32)
    feature_names = fn_dlls + fn_api + fn_hdr + fn_sect
    # ^ feature_names phải khớp đúng thứ tự cột sau khi hstack, để sau này interpret model/feature importance.

    if logger:
        density = X.nnz / (X.shape[0] * X.shape[1]) if (X.shape[0] * X.shape[1]) > 0 else 0
        sparsity = 1 - density
        logger.info(f"FINAL X: shape={X.shape}, nnz={X.nnz:,}, density={density:.4%} sparsity={sparsity:.4%} mem={human_bytes(sparse_memory_bytes(X))}")
        logger.info(f"FINAL y: shape={y.shape}, unique_classes={len(pd.unique(y))}")

    return X, y, sha_arr, feature_names


def processed_paths(cfg: Config) -> Dict[str, Path]:
    # Tạo ra các đường dẫn chuẩn cho “processed cache”
    # pdir = data_dir/processed_dirname, ví dụ: /data/processed/
    pdir = Path(cfg.data_dir) / cfg.processed_dirname
    return {
        "dir": pdir,
        "X": pdir / cfg.processed_X_name,             # file sparse matrix (npz) cho X
        "y": pdir / cfg.processed_y_name,             # file npy cho y
        "sha": pdir / cfg.processed_sha_name,         # file npy cho sha256
        "feat": pdir / cfg.processed_feat_name,       # json cho feature_names
        "classes": pdir / cfg.processed_classes_name, # (dự phòng) danh sách class/nhãn
    }


def save_processed(cfg: Config, X: sp.csr_matrix, y: np.ndarray, sha: np.ndarray, feature_names: List[str], logger=None) -> None:
    # Lưu dataset đã xử lý xuống disk để lần sau load nhanh (cache).
    paths = processed_paths(cfg)
    paths["dir"].mkdir(parents=True, exist_ok=True)  # tạo folder nếu chưa có

    # 1) Sparse matrix: dùng SciPy save_npz (đúng chuẩn cho sparse)
    sp.save_npz(paths["X"], X)

    # 2) y và sha: lưu bằng np.save -> .npy
    # allow_pickle=True: cho phép lưu dtype=object (string, mixed types).
    # (Chỉ dùng khi file do bạn tự tạo và tin cậy.)
    np.save(paths["y"], y, allow_pickle=True)
    np.save(paths["sha"], sha, allow_pickle=True)

    # 3) feature_names: lưu JSON để đọc dễ, kiểm soát thứ tự cột.
    dump_json(paths["feat"], feature_names)

    if logger:
        logger.info(f"Saved processed dataset to: {paths['dir']}")


def load_processed(cfg: Config, logger=None) -> Optional[Tuple[sp.csr_matrix, np.ndarray, np.ndarray, List[str]]]:
    # Load cache nếu tồn tại; nếu thiếu file nào thì trả None (caller sẽ build lại từ raw CSV).
    paths = processed_paths(cfg)
    if not paths["X"].exists() or not paths["y"].exists() or not paths["sha"].exists() or not paths["feat"].exists():
        return None

    # 1) Sparse matrix: phải dùng sp.load_npz để đọc đúng sparse format
    X = sp.load_npz(paths["X"]).tocsr()
    # ^ .tocsr() đảm bảo đúng CSR (đôi khi file có thể lưu format khác, hoặc bạn muốn chắc chắn).

    # 2) Load y, sha từ .npy
    # allow_pickle=True vì y/sha có thể là dtype object (string).
    y = np.load(paths["y"], allow_pickle=True)
    sha = np.load(paths["sha"], allow_pickle=True)

    # 3) Load feature_names từ JSON
    import json
    with paths["feat"].open("r", encoding="utf-8") as f:
        feature_names = json.load(f)


    # nnz (Number of Non-Zeros): Số lượng các giá trị khác 0. Đây là chỉ số quan trọng nhất để đánh giá độ thưa (Sparsity) của dữ liệu malware.
    # sparse_memory_bytes: Hàm tính toán dung lượng RAM cần thiết để lưu trữ ma trận sparse.
    # human_bytes: Hàm chuyển đổi dung lượng bytes thành đơn vị dễ đọc (KB, MB, GB).
    if logger:
        logger.info(f"Loaded processed dataset from: {paths['dir']}")
        density = X.nnz / (X.shape[0] * X.shape[1]) if (X.shape[0] * X.shape[1]) > 0 else 0
        sparsity = 1 - density
        logger.info(f"X.shape={X.shape} nnz={X.nnz:,} density={density:.4%} sparsity={sparsity:.4%} mem={human_bytes(sparse_memory_bytes(X))}")
        logger.info(f"y.shape={y.shape} unique={len(pd.unique(y))}")

    # Trả về tuple (X, y, sha, feature_names). Nếu load fail ở đầu hàm thì trả None.
    return X, y, sha, feature_names
