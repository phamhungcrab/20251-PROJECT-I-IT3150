"""
train_models.py

File này chứa các hàm train model cho bài toán phân loại malware (đa lớp / multiclass).
Có 2 hướng chính:
1) Logistic Regression (ElasticNet / L1 / L2) -> rất hợp dữ liệu sparse (API/DLL giống bag-of-words)
2) LightGBM (baseline + optional Optuna tuning) -> mạnh cho tabular và cũng xử lý được sparse

Mục tiêu chung:
- Train trên (X_train, y_train)
- Đánh giá trên (X_val, y_val) để chọn tham số tốt nhất
- KHÔNG dùng test trong quá trình chọn tham số (tránh data leakage)
"""

from __future__ import annotations

import math
import random
# math, random hiện chưa dùng trực tiếp trong đoạn code này
# (có thể do phần khác hoặc code cũ). Nếu không dùng có thể xoá để đỡ rối.

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import scipy.sparse as sp
# sp.csr_matrix là ma trận sparse dạng CSR (Compressed Sparse Row).
# Dữ liệu kiểu DLL/API thường có rất nhiều cột 0/1 nên cực kỳ sparse -> CSR giúp tiết kiệm RAM.

from sklearn.feature_selection import VarianceThreshold
# VarianceThreshold: loại bỏ các cột có variance thấp (thường là cột luôn bằng 0 hoặc gần như không đổi).
# Trong dữ liệu sparse, có thể có nhiều feature xuất hiện cực ít hoặc không xuất hiện -> bỏ đi cho nhẹ.

from sklearn.linear_model import LogisticRegression
# LogisticRegression: mô hình tuyến tính dùng softmax (multinomial) cho multiclass.
# Ưu điểm: nhanh, ổn định, giải thích được qua hệ số (coef).

from sklearn.pipeline import Pipeline
# Pipeline: xâu chuỗi các bước xử lý + model để đảm bảo "fit" đúng cách (tránh leakage)
# và code gọn hơn.

from sklearn.preprocessing import MaxAbsScaler
# MaxAbsScaler: scale dữ liệu về [-1, 1] dựa trên giá trị tuyệt đối lớn nhất theo từng cột.
# Điểm hay: hoạt động tốt với sparse matrix (không phá sparse như StandardScaler).

from .config import Config
from .evaluate import compute_metrics
# compute_metrics: hàm tính accuracy, balanced_accuracy, f1_macro, f1_weighted, log_loss...


# ==========================================================
# 1) Dataclass để đóng gói kết quả train
# ==========================================================

@dataclass
class TrainResult:
    """
    TrainResult giúp trả về kết quả train theo cấu trúc rõ ràng.

    - name: tên mô hình (logreg / lgbm / lgbm_optuna...)
    - model: đối tượng model đã fit (Pipeline hoặc LGBMClassifier)
    - val_metrics: các metric trên validation (dùng để so sánh)
    - best_params: tham số tốt nhất (để ghi log / lưu report / tái lập)
    """
    name: str
    model: Any
    val_metrics: Dict[str, Any]
    best_params: Dict[str, Any]


# ==========================================================
# 2) Logistic Regression + ElasticNet grid search
# ==========================================================

def train_logreg_elasticnet(
    X_train: sp.csr_matrix,
    y_train: np.ndarray,
    X_val: sp.csr_matrix,
    y_val: np.ndarray,
    cfg: Config,
    logger=None,
) -> TrainResult:
    """
    Train Logistic Regression (multiclass) + regularization (L1/L2/ElasticNet).

    Vì sao hợp với dữ liệu này?
    - DLL/API features giống "bag-of-words": rất nhiều feature nhị phân (0/1), sparse
    - Logistic Regression với solver 'saga' chạy tốt trên sparse + multinomial
    - Regularization giúp tránh overfitting và có thể làm "feature selection" (đặc biệt L1)

    Mục tiêu hàm:
    - Thử nhiều giá trị C và l1_ratio (grid search thủ công)
    - Chọn mô hình tốt nhất theo metric cfg.metric_for_model_select trên tập validation

    Lưu ý quan trọng về leakage:
    - Chỉ train trên train
    - Chọn best theo val
    - Không dùng test ở đây
    """

    # best_score: điểm cao nhất đã thấy (khởi tạo rất nhỏ)
    best_score = -1e9
    best_model = None
    best_params: Dict[str, Any] = {}
    best_metrics: Dict[str, Any] = {}

    # lấy grid từ config
    C_grid = list(cfg.logreg_C_grid)
    l1r_grid = list(cfg.logreg_l1_ratio_grid)

    if logger:
        logger.info(f"[LogReg] grid search: C={C_grid}, l1_ratio={l1r_grid}")

    # Grid search thủ công: thử mọi cặp (C, l1_ratio)
    for C in C_grid:
        for l1_ratio in l1r_grid:

            # ----------------------------------------------------------
            # Map l1_ratio -> penalty (vì sklearn LogisticRegression có quy tắc)
            #
            # - l1_ratio = 0   -> L2
            # - l1_ratio = 1   -> L1
            # - 0<l1_ratio<1   -> ElasticNet (kết hợp L1 và L2)
            #
            # Với L1 hoặc L2 thuần, sklearn không cần truyền l1_ratio.
            # ----------------------------------------------------------
            if l1_ratio <= 0.0:
                penalty = "l2"
                l1r = None
            elif l1_ratio >= 1.0:
                penalty = "l1"
                l1r = None
            else:
                penalty = "elasticnet"
                l1r = float(l1_ratio)

            # ----------------------------------------------------------
            # Khởi tạo LogisticRegression
            # ----------------------------------------------------------
            clf = LogisticRegression(
                penalty=penalty,
                solver="saga",
                # saga hỗ trợ: l1, l2, elasticnet + sparse + multinomial

                l1_ratio=l1r,               # chỉ dùng khi penalty="elasticnet"
                C=float(C),                 # C lớn -> ít regularize hơn; C nhỏ -> regularize mạnh hơn
                max_iter=int(cfg.logreg_max_iter),
                # tol=float(getattr(cfg, "logreg_tol", 1e-4)), # Use relaxed tolerance if available, else default
                n_jobs=int(cfg.n_jobs),

                class_weight="balanced",
                # class_weight="balanced": tự cân bằng trọng số lớp theo tần suất
                # hữu ích khi dữ liệu lệch lớp (một vài malware family ít mẫu)

                # multi_class="multinomial" đã deprecated trong sklearn 1.5+
                # Mặc định sklearn đã dùng multinomial, không cần truyền

                random_state=int(cfg.random_state),
                verbose=0,
            )

            # ----------------------------------------------------------
            # Pipeline các bước:
            # 1) VarianceThreshold: loại các cột không thay đổi (variance=0)
            #    -> nếu một feature luôn bằng 0 ở train thì không giúp gì
            #
            # 2) MaxAbsScaler: scale phù hợp cho sparse
            #
            # 3) clf: LogisticRegression
            #
            # Pipeline đảm bảo scaler/VT chỉ fit trên train, rồi transform val đúng cách.
            # ----------------------------------------------------------
            pipe = Pipeline(
                steps=[
                    ("vt", VarianceThreshold(threshold=0.0)),
                    ("scaler", MaxAbsScaler()),
                    ("clf", clf),
                ]
            )

            if logger:
                logger.info(f"[LogReg] Training: C={C}, penalty={penalty}, l1_ratio={l1_ratio}")

            # Train (fit) pipeline trên train
            pipe.fit(X_train, y_train)

            # ===== Log convergence status =====
            # n_iter_: số iteration thực tế đã chạy (mỗi class 1 giá trị cho multinomial)
            # Nếu n_iter_ == max_iter → chưa hội tụ, cần tăng max_iter
            logreg_clf = pipe.named_steps["clf"]
            n_iter = logreg_clf.n_iter_  # array of shape (n_classes,) hoặc (1,)
            max_iter_used = int(cfg.logreg_max_iter)

            # Kiểm tra: nếu bất kỳ class nào đạt max_iter thì chưa hội tụ
            converged = all(n < max_iter_used for n in n_iter)

            if logger:
                iter_str = ",".join(str(n) for n in n_iter)
                status = "✓ CONVERGED" if converged else "✗ NOT CONVERGED (consider increasing max_iter)"
                logger.info(f"[LogReg] Convergence: n_iter=[{iter_str}] max_iter={max_iter_used} {status}")
            # ==================================

            # Dự đoán nhãn trên validation
            y_pred = pipe.predict(X_val)

            # Dự đoán xác suất (nếu có) để tính log_loss
            y_proba = None
            if hasattr(pipe, "predict_proba"):
                try:
                    y_proba = pipe.predict_proba(X_val)
                except Exception:
                    y_proba = None

            # Tính metrics
            metrics = compute_metrics(y_val, y_pred, y_proba=y_proba)

            # score để so sánh theo metric config chọn (vd f1_macro)
            score = metrics.get(cfg.metric_for_model_select, metrics["f1_macro"])

            if logger:
                logger.info(f"[LogReg] VAL metrics: {metrics}")

            # Cập nhật best nếu tốt hơn
            if score > best_score:
                best_score = score
                best_model = pipe
                best_params = {"C": float(C), "penalty": penalty, "l1_ratio": float(l1_ratio)}
                best_metrics = metrics

    # đảm bảo đã tìm được model
    assert best_model is not None

    if logger:
        logger.info(f"[LogReg] BEST params={best_params} best_val={best_metrics}")

    return TrainResult(
        name="logreg",
        model=best_model,
        val_metrics=best_metrics,
        best_params=best_params,
    )


# ==========================================================
# 3) LightGBM import an toàn (có thì dùng, không có thì skip)
# ==========================================================

def _try_import_lightgbm():
    """
    Vì lightgbm có thể chưa được cài trên môi trường,
    ta import thử:
    - thành công -> trả module lightgbm
    - thất bại  -> trả None
    """
    try:
        import lightgbm as lgb  # type: ignore
        return lgb
    except Exception:
        return None


# ==========================================================
# 4) Train LightGBM baseline + early stopping
# ==========================================================

def train_lgbm(
    X_train: sp.csr_matrix,
    y_train: np.ndarray,
    X_val: sp.csr_matrix,
    y_val: np.ndarray,
    cfg: Config,
    logger=None,
) -> Optional[TrainResult]:

    """
    Train LightGBM (multiclass) với early stopping.

    Vì sao dùng LightGBM?
    - Gradient Boosting Decision Trees rất mạnh với dữ liệu tabular
    - Có thể xử lý feature nhiều và tương tác phi tuyến
    - Không cần scaling (khác Logistic Regression)
    - Có thể tận dụng early stopping để dừng sớm khi bắt đầu overfit

    Trả về None nếu môi trường chưa cài lightgbm.
    """

    lgb = _try_import_lightgbm()
    if lgb is None:
        if logger:
            logger.warning("LightGBM not installed. Skip. (pip install lightgbm)")
        return None

    # số lớp (family) trong y_train
    n_classes = int(len(np.unique(y_train)))

    # baseline params (mặc định khá “ổn”, chưa tune)
    params = dict(
        objective="multiclass",
        num_class=n_classes,
        n_estimators=int(cfg.lgbm_num_boost_round),  # tối đa số cây
        learning_rate=0.05,                         # tốc độ học (nhỏ -> cần nhiều cây hơn nhưng ổn định hơn)
        num_leaves=128,                             # độ phức tạp cây (lá nhiều -> model phức tạp hơn)
        max_depth=-1,                               # -1 nghĩa là không giới hạn depth (nhưng vẫn bị ràng bởi num_leaves)
        min_child_samples=50,                       # tối thiểu số mẫu trong 1 lá (tăng để giảm overfitting)
        subsample=0.8,                              # sampling theo hàng (bagging)
        subsample_freq=1,
        colsample_bytree=0.8,                       # sampling theo cột
        reg_alpha=0.0,                              # L1 regularization
        reg_lambda=0.0,                             # L2 regularization
        class_weight="balanced",                    # tự cân bằng trọng số lớp theo tần suất (quan trọng khi imbalanced)
        random_state=int(cfg.random_state),
        n_jobs=int(cfg.n_jobs),
        verbose=-1,                                  # Suppress LightGBM internal warnings
    )

    if logger:
        logger.info(f"[LGBM] baseline params={params}")

    clf = lgb.LGBMClassifier(**params)

    # fit với validation để early stopping hoạt động
    clf.fit(
        X_train,
        y_train,
        eval_set=[(X_val, y_val)],                  # validation set
        eval_metric="multi_logloss",                # metric theo dõi
        callbacks=[
            lgb.early_stopping(
                stopping_rounds=int(cfg.lgbm_early_stopping_rounds),
                verbose=bool(logger)
            ),
        ],
    )

    # dự đoán validation
    y_pred = clf.predict(X_val)

    # dự đoán xác suất cho log_loss
    y_proba = None
    try:
        y_proba = clf.predict_proba(X_val)
    except Exception:
        pass

    metrics = compute_metrics(y_val, y_pred, y_proba=y_proba)

    # lưu params + best_iteration_ (nếu có)
    best_params = params.copy()
    if hasattr(clf, "best_iteration_") and clf.best_iteration_ is not None:
        best_params["best_iteration_"] = int(clf.best_iteration_)

    if logger:
        logger.info(f"[LGBM] VAL metrics: {metrics}")
        if "best_iteration_" in best_params:
            logger.info(f"[LGBM] best_iteration_ = {best_params['best_iteration_']}")

    return TrainResult(name="lgbm", model=clf, val_metrics=metrics, best_params=best_params)


# ==========================================================
# 5) Tune LightGBM bằng Optuna (tuỳ chọn)
# ==========================================================

def train_lgbm_optuna(
    X_train: sp.csr_matrix,
    y_train: np.ndarray,
    X_val: sp.csr_matrix,
    y_val: np.ndarray,
    cfg: Config,
    logger=None,
) -> Optional[TrainResult]:
    """
    Tune LightGBM bằng Optuna để tối ưu metric trên validation.

    Khái niệm nhanh:
    - Optuna là thư viện tối ưu tham số (hyperparameter optimization).
    - Mỗi lần thử = 1 trial, Optuna chọn 1 bộ tham số -> train -> đo metric -> cập nhật chiến lược chọn trial tiếp theo.
    - Ở đây ta "maximize" metric (vd f1_macro).

    Đảm bảo không leakage:
    - Tuning chỉ dùng train + val
    - Không đụng test

    Trả về None nếu thiếu lightgbm hoặc optuna.
    """
    lgb = _try_import_lightgbm()
    if lgb is None:
        if logger:
            logger.warning("LightGBM not installed. Skip optuna.")
        return None

    try:
        import optuna  # type: ignore
    except Exception:
        if logger:
            logger.warning("Optuna not installed. Skip optuna. (pip install optuna)")
        return None

    n_classes = int(len(np.unique(y_train)))
    metric_name = cfg.metric_for_model_select

    def objective(trial):
        """
        objective(trial) là hàm mà Optuna sẽ gọi nhiều lần.
        Nó phải trả về 1 số (metric) để Optuna tối ưu.

        trial.suggest_*:
        - Optuna tự chọn giá trị trong khoảng bạn cho
        - Ví dụ suggest_float("learning_rate", 0.01, 0.2) nghĩa là thử LR trong [0.01, 0.2]
        """

        params = {
            "objective": "multiclass",
            "num_class": n_classes,
            "n_estimators": int(cfg.lgbm_num_boost_round),

            # các tham số Optuna sẽ thử
            "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.2, log=True),
            "num_leaves": trial.suggest_int("num_leaves", 31, 255),
            "max_depth": trial.suggest_int("max_depth", -1, 16),
            "min_child_samples": trial.suggest_int("min_child_samples", 10, 200),
            "subsample": trial.suggest_float("subsample", 0.5, 1.0),
            "subsample_freq": 1,
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 1.0),
            "reg_alpha": trial.suggest_float("reg_alpha", 1e-8, 10.0, log=True),
            "reg_lambda": trial.suggest_float("reg_lambda", 1e-8, 10.0, log=True),
            "class_weight": "balanced",  # cân bằng trọng số lớp

            "random_state": int(cfg.random_state),
            "n_jobs": int(cfg.n_jobs),
            "verbose": -1,               # Suppress LightGBM internal warnings
        }

        clf = lgb.LGBMClassifier(**params)
        clf.fit(
            X_train,
            y_train,
            eval_set=[(X_val, y_val)],
            eval_metric="multi_logloss",
            callbacks=[lgb.early_stopping(stopping_rounds=int(cfg.lgbm_early_stopping_rounds), verbose=False)],
        )

        y_pred = clf.predict(X_val)

        y_proba = None
        try:
            y_proba = clf.predict_proba(X_val)
        except Exception:
            pass

        metrics = compute_metrics(y_val, y_pred, y_proba=y_proba)

        # trả về metric mà bạn muốn tối ưu
        return metrics.get(metric_name, metrics["f1_macro"])

    if logger:
        logger.info(f"[Optuna-LGBM] Start tuning: trials={cfg.lgbm_trials} metric={metric_name}")

    # study là "quá trình tối ưu"
    study = optuna.create_study(direction="maximize")
    study.optimize(objective, n_trials=int(cfg.lgbm_trials), show_progress_bar=bool(logger))

    best_trial = study.best_trial
    if logger:
        logger.info(f"[Optuna-LGBM] Best value={best_trial.value} params={best_trial.params}")

    # ----------------------------------------------------------
    # Sau khi tìm ra best params -> train lại một lần với best params
    # (để có model cuối cùng + metrics)
    # ----------------------------------------------------------
    best_params = {
        "objective": "multiclass",
        "num_class": n_classes,
        "n_estimators": int(cfg.lgbm_num_boost_round),
        "random_state": int(cfg.random_state),
        "n_jobs": int(cfg.n_jobs),
        **best_trial.params,
        "subsample_freq": 1,
    }

    clf = lgb.LGBMClassifier(**best_params)
    clf.fit(
        X_train,
        y_train,
        eval_set=[(X_val, y_val)],
        eval_metric="multi_logloss",
        callbacks=[lgb.early_stopping(stopping_rounds=int(cfg.lgbm_early_stopping_rounds), verbose=bool(logger))],
    )

    y_pred = clf.predict(X_val)

    y_proba = None
    try:
        y_proba = clf.predict_proba(X_val)
    except Exception:
        pass

    metrics = compute_metrics(y_val, y_pred, y_proba=y_proba)

    if hasattr(clf, "best_iteration_") and clf.best_iteration_ is not None:
        best_params["best_iteration_"] = int(clf.best_iteration_)

    return TrainResult(name="lgbm_optuna", model=clf, val_metrics=metrics, best_params=best_params)
