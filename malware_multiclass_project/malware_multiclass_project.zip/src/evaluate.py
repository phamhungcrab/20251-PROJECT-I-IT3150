"""
metrics_utils.py

File này chứa các hàm "đánh giá mô hình" (evaluation):
- Tính các metric phổ biến: accuracy, balanced accuracy, F1 (macro/weighted), log-loss
- In báo cáo classification_report + confusion matrix (bảng nhầm lẫn)
- Ghi log các cặp nhầm lẫn nhiều nhất (true -> pred)
- Lưu metric ra file JSON để đưa vào báo cáo / lưu lịch sử thí nghiệm

Mục tiêu của file:
- Tách phần đánh giá ra khỏi phần train để code sạch và tái sử dụng được.
"""

from __future__ import annotations
# Giống như đã giải thích: giúp type hint linh hoạt hơn.

import json
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
# numpy dùng để thao tác mảng, tính toán vector/matrix.

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    log_loss,
)
# sklearn.metrics là các hàm "đo chất lượng" dự đoán.
# - accuracy_score: % dự đoán đúng
# - balanced_accuracy_score: accuracy nhưng cân bằng theo lớp (hữu ích khi lệch lớp)
# - classification_report: in precision/recall/F1 theo từng lớp
# - confusion_matrix: bảng nhầm lẫn (true vs predicted)
# - f1_score: F1 (kết hợp precision & recall)
# - log_loss: đo chất lượng xác suất dự đoán (càng thấp càng tốt)


def compute_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_proba: Optional[np.ndarray] = None,
) -> Dict[str, Any]:
    """
    Tính các metric cơ bản và trả về dưới dạng dict.

    Tham số:
    - y_true: nhãn thật (ground truth), ví dụ [0,1,0,1,...]
    - y_pred: nhãn mô hình dự đoán, ví dụ [0,1,1,1,...]
    - y_proba: (tùy chọn) xác suất dự đoán của mô hình.
      Ví dụ binary classification:
        y_proba có thể là:
        - shape (N,)    : xác suất class=1 cho mỗi mẫu
        - shape (N, 2)  : xác suất cho cả 2 lớp [P(class0), P(class1)]
      Multi-class:
        shape (N, K)    : xác suất cho K lớp

    Trả về:
    - dict: {"accuracy":..., "balanced_accuracy":..., "f1_macro":..., "f1_weighted":..., "log_loss":...}
    """

    # float(...) để đảm bảo kết quả JSON-serializable (numpy float đôi khi dump JSON lỗi)
    m = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        # accuracy = số dự đoán đúng / tổng số mẫu
        # Ví dụ đúng 93/100 -> 0.93

        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        # balanced_accuracy = trung bình recall theo từng lớp.
        # Rất quan trọng khi dữ liệu lệch lớp (ví dụ benign nhiều hơn malware).

        "f1_macro": float(f1_score(y_true, y_pred, average="macro")),
        # f1_macro: tính F1 riêng cho từng lớp rồi lấy trung bình đều.
        # Mỗi lớp "được coi quan trọng như nhau" (tốt khi lệch lớp).

        "f1_weighted": float(f1_score(y_true, y_pred, average="weighted")),
        # f1_weighted: giống macro nhưng trung bình có trọng số theo số lượng mẫu của mỗi lớp.
        # Lớp nhiều mẫu ảnh hưởng nhiều hơn.
    }

    # log_loss chỉ tính được khi có xác suất dự đoán y_proba
    if y_proba is not None:
        try:
            m["log_loss"] = float(log_loss(y_true, y_proba))
            # log_loss: đo mức "tự tin đúng" của mô hình.
            # Nếu mô hình dự đoán xác suất sai nhưng lại rất tự tin (ví dụ 0.99 mà sai)
            # -> log_loss sẽ phạt rất nặng.
            # log_loss càng thấp càng tốt.
        except Exception:
            # Một số trường hợp y_proba shape không đúng, hoặc chỉ có 1 class trong split...
            # -> log_loss có thể throw error. Ta bắt lỗi để pipeline không crash.
            m["log_loss"] = None

    return m


def print_report(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    classes: list,
    title: str,
    logger=None,
    y_proba: Optional[np.ndarray] = None,
) -> Dict[str, Any]:
    """
    In báo cáo đánh giá + confusion matrix để debug (thường dùng khi train xong).

    Tham số:
    - y_true, y_pred: như trên
    - classes: danh sách tên lớp theo thứ tự index.
      Ví dụ binary: ["benign", "malware"]
      Multi-class: ["benign", "family1", "family2", ...]
    - title: tiêu đề để log (ví dụ "Validation", "Test", ...)
    - logger: đối tượng logger (vd logging.getLogger()) để ghi ra file log.
              Nếu logger=None thì hàm vẫn trả metrics nhưng không in/log.
    - y_proba: xác suất dự đoán (tùy chọn) để tính log_loss

    Trả về:
    - metrics dict
    """

    # 1) Tính metric dạng dict
    metrics = compute_metrics(y_true, y_pred, y_proba=y_proba)

    # 2) Nếu có logger thì ghi log chi tiết
    if logger:
        logger.info(f"===== {title} =====")
        logger.info("Metrics: " + json.dumps(metrics, ensure_ascii=False))
        # json.dumps(...) để in dict thành chuỗi JSON, dễ đọc trong log.
        # ensure_ascii=False để giữ tiếng Việt không bị escape.

        # classification_report: in precision/recall/F1 theo từng lớp
        # precision: trong các mẫu dự đoán là lớp X, bao nhiêu % là đúng
        # recall: trong các mẫu thật là lớp X, mô hình bắt được bao nhiêu %
        # f1: trung bình điều hòa của precision & recall
        rep = classification_report(y_true, y_pred, target_names=classes, digits=4)
        logger.info("\n" + rep)

        # confusion_matrix: bảng nhầm lẫn (đếm số lượng)
        # Hàng = lớp thật (true), cột = lớp dự đoán (pred)
        cm = confusion_matrix(y_true, y_pred)
        logger.info("Confusion matrix (counts):")
        logger.info("\n" + _format_cm(cm, classes))

        # confusion matrix normalized theo hàng:
        # cmn[i, j] = tỉ lệ mẫu lớp thật i bị dự đoán thành j
        # Ví dụ hàng "benign": [0.90, 0.10] nghĩa là benign đúng 90%, nhầm sang malware 10%
        cmn = cm.astype(np.float64) / np.maximum(1, cm.sum(axis=1, keepdims=True))
        # np.maximum(1, ...) để tránh chia cho 0 nếu có lớp không xuất hiện trong split.
        logger.info("Confusion matrix (row-normalized):")
        logger.info("\n" + _format_cm(cmn, classes, float_fmt="{:0.2f}"))

        # Log thêm: các cặp nhầm lẫn nhiều nhất (bỏ đường chéo)
        _log_top_confusions(cm, classes, logger, topk=10)

    return metrics


def _format_cm(cm: np.ndarray, classes: list, float_fmt="{:0.0f}") -> str:
    """
    Hàm phụ (private) để format confusion matrix thành bảng chữ đẹp trong log.

    Tham số:
    - cm: confusion matrix (đếm hoặc normalized)
    - classes: tên lớp
    - float_fmt: định dạng số khi in:
      - "{:0.0f}" in số nguyên (cho counts)
      - "{:0.2f}" in số thực 2 chữ số (cho normalized)
    """
    # Độ rộng cố định cho mỗi cột giá trị
    col_width = 8

    # Tính độ rộng tối đa cho tên lớp (để căn chỉnh row label)
    max_class_len = max(len(str(c)[:col_width]) for c in classes)
    # Row label format: "true <class>" - tổng độ rộng = 5 ("true ") + max_class_len
    row_label_width = 5 + max_class_len

    # Tạo header: phần label trống + tên các lớp (predicted)
    # Header label: căn phải với row_label_width để khớp với data rows
    header_label = f"{'pred→':>{row_label_width}}"
    header_cols = " ".join([f"{str(c)[:col_width]:>{col_width}}" for c in classes])
    header = f"{header_label} {header_cols}"

    # Separator line
    separator = "-" * len(header)

    lines = [header, separator]
    for i, row in enumerate(cm):
        # Row label: "true <class>" căn phải với row_label_width
        class_name = str(classes[i])[:col_width]
        row_label = f"{'true ' + class_name:>{row_label_width}}"
        # Giá trị các cột - có space giữa các cột
        row_values = " ".join([f"{float_fmt.format(x):>{col_width}}" for x in row])
        lines.append(f"{row_label} {row_values}")

    return "\n".join(lines)


def _log_top_confusions(cm: np.ndarray, classes: list, logger, topk: int = 10) -> None:
    """
    In ra top các cặp (true -> pred) bị nhầm nhiều nhất (bỏ diagonal).

    Ví dụ:
    - "Benign -> Malware" bị nhầm 200 lần
    - "Trojan -> Worm" bị nhầm 35 lần
    ...

    Ý nghĩa:
    - Giúp bạn hiểu mô hình đang nhầm lớp nào với lớp nào nhiều nhất,
      từ đó tìm nguyên nhân (feature chưa đủ phân biệt, dữ liệu nhiễu, class imbalance,...)
    """

    # copy để không làm thay đổi matrix gốc
    cm = cm.copy()

    # fill diagonal = 0 để bỏ phần dự đoán đúng (true==pred)
    np.fill_diagonal(cm, 0)

    pairs = []
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            if cm[i, j] > 0:
                # lưu tuple: (số lần nhầm, i=true_class, j=pred_class)
                pairs.append((int(cm[i, j]), i, j))

    # sort giảm dần theo số lần nhầm
    pairs.sort(reverse=True)

    if not pairs:
        logger.info("No confusions (perfect classification on this split).")
        return

    logger.info(f"Top confusions (count, true -> pred):")
    for k, (cnt, i, j) in enumerate(pairs[:topk], start=1):
        logger.info(f"  {k:>2}. {cnt:>6} : {classes[i]} -> {classes[j]}")


def save_metrics_json(path: Path, metrics: Dict[str, Any]) -> None:
    """
    Lưu metrics dict ra file JSON.

    Tham số:
    - path: đường dẫn file JSON sẽ lưu (vd outputs/reports/metrics_test.json)
    - metrics: dict metric (đã tính từ compute_metrics / print_report)

    Lý do nên lưu JSON:
    - dễ tổng hợp, vẽ biểu đồ, so sánh thí nghiệm
    - đưa vào báo cáo / luận văn dễ dàng
    """

    # đảm bảo thư mục cha tồn tại
    path.parent.mkdir(parents=True, exist_ok=True)

    # mở file và ghi JSON
    with path.open("w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)
        # indent=2 để JSON đẹp, dễ đọc
