"""
data_io.py

File này lo phần đọc dữ liệu (CSV) và cache lại dưới dạng Parquet để lần sau đọc nhanh hơn.

Dataset của bạn có 4 file CSV:
1) DLLs_Imported.csv   (rất nhiều cột 0/1 -> dữ liệu thưa, đọc CSV sẽ nặng)
2) API_Functions.csv   (tương tự: nhiều cột 0/1)
3) PE_Header.csv       (các cột số, continuous/discrete)
4) PE_Section.csv      (các cột số theo section)

Ý tưởng tối ưu:
- Với file binary (0/1): ép dtype int8 để giảm RAM (int8 chỉ 1 byte)
- Với file numeric: để pandas tự infer dtype (int/float), vẫn cache Parquet
- Dùng chunksize để đọc từng phần, tránh “ngốn RAM” khi file lớn
- Cache Parquet để tốc độ load lần sau nhanh hơn CSV rất nhiều
"""

from __future__ import annotations

import time
# time dùng để đo thời gian xử lý (timer)

from pathlib import Path
# Path giúp xử lý đường dẫn file/folder an toàn hơn string.

from typing import Optional, Tuple
# Tuple dùng cho type hint: hàm load_all_dfs trả về 4 DataFrame.
# Optional dùng cho logger parameter (có thể None)

import logging
# logging để ghi log chi tiết thời gian xử lý

import pandas as pd
# pandas là thư viện chính để đọc CSV và xử lý bảng dữ liệu (DataFrame).

from .config import Config
# Import Config từ file config.py trong cùng package/module.
# Config chứa data_dir, cache_dir, tên file CSV, chunksize, use_cache,...


def _lower_strip_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Hàm phụ (private) để chuẩn hoá tên cột:
    - strip(): bỏ khoảng trắng đầu/cuối
    - lower(): chuyển thành chữ thường

    Tại sao cần?
    - CSV đôi khi có cột " SHA256 " hoặc "Type" / "type"
    - Nếu không chuẩn hoá, lúc merge/join hoặc chọn cột dễ bị lỗi do sai tên cột.
    """
    df.columns = [c.strip().lower() for c in df.columns]
    return df


def read_binary_fast(
    csv_path: Path,
    cache_dir: Path,
    use_cache: bool = True,
    chunksize: int = 5000,
    logger: Optional[logging.Logger] = None
) -> pd.DataFrame:
    """
    Đọc CSV dạng binary features (0/1) và tối ưu bộ nhớ bằng int8 + Parquet cache.

    Phù hợp cho:
    - DLLs_Imported.csv
    - API_Functions.csv

    Vì sao cần tối ưu?
    - Các file này thường có rất nhiều cột (mỗi DLL/API là một cột)
    - Giá trị thường chỉ là 0 hoặc 1, nên không cần int64 (tốn 8 byte)
    - int8 chỉ tốn 1 byte -> giảm RAM ~8 lần cho phần 0/1

    Tham số:
    - csv_path: đường dẫn tới file CSV
    - cache_dir: thư mục lưu cache parquet
    - use_cache: True -> nếu có parquet thì đọc parquet luôn (nhanh)
    - chunksize: đọc CSV theo từng khối để không tốn RAM
    """
    csv_path = Path(csv_path)
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)  # tạo folder cache nếu chưa có

    # Tên file cache: DLLs_Imported_binary.parquet chẳng hạn
    #csv_path.name -> "API_Functions.csv" (Tên đầy đủ)
    # csv_path.suffix -> ".csv" (Đuôi file)
    # csv_path.stem -> "API_Functions" (Chỉ lấy phần tên, bỏ đuôi)
    parquet_path = cache_dir / (csv_path.stem + "_binary.parquet")

    # Nếu bật cache và file parquet đã tồn tại -> đọc parquet cho nhanh
    if use_cache and parquet_path.exists():
        t0 = time.time()
        df = pd.read_parquet(parquet_path)
        if logger:
            logger.info(f"[IO] Read parquet cache {parquet_path.name}: {time.time()-t0:.2f}s")
        return _lower_strip_columns(df)

    # ---- Nếu chưa có cache: đọc CSV và tạo cache ----
    if logger:
        logger.info(f"[IO] Reading CSV {csv_path.name} (no cache found)...")
    t0_csv = time.time()

    # Đọc thử 5 dòng để biết danh sách cột (infer cột)
    # (Chỉ cần biết tên cột để set dtype phù hợp)
    sample = pd.read_csv(csv_path, nrows=5)

    # dtypes: dict mapping {tên_cột: kiểu_dữ_liệu}
    dtypes = {}
    for col in sample.columns:
        col_lower = col.strip().lower()

        # sha256 và type là thông tin định danh + nhãn -> giữ kiểu object/string
        if col_lower in ["sha256", "type"]:
            dtypes[col] = "object"
        else:
            # Các cột còn lại (DLL/API xuất hiện hay không) -> 0/1 -> dùng int8
            dtypes[col] = "int8"

    # Đọc CSV theo chunks với dtype đã set.
    # pd.read_csv(..., chunksize=...) trả về iterator (đọc từng phần)
    chunks = pd.read_csv(csv_path, dtype=dtypes, chunksize=chunksize)

    # Ghép các chunks lại thành 1 DataFrame lớn
    df = pd.concat(chunks, ignore_index=True)

    # Chuẩn hóa tên cột (lower+strip)
    df = _lower_strip_columns(df)

    if logger:
        logger.info(f"[IO] Read CSV {csv_path.name}: {time.time()-t0_csv:.2f}s rows={len(df):,}")

    # Luôn lưu cache sau khi đã đọc CSV (để lần sau nhanh hơn)
    t0_pq = time.time()
    df.to_parquet(parquet_path, index=False)
    if logger:
        logger.info(f"[IO] Saved parquet cache {parquet_path.name}: {time.time()-t0_pq:.2f}s")

    return df


def read_continuous(
    csv_path: Path,
    cache_dir: Path,
    use_cache: bool = True,
    chunksize: int = 5000,
    logger: Optional[logging.Logger] = None
) -> pd.DataFrame:
    """
    Đọc CSV dạng numeric features (continuous/discrete) + Parquet cache.

    Phù hợp cho:
    - PE_Header.csv
    - PE_Section.csv

    Vì sao không ép dtype như binary?
    - Các cột có thể là int/float, giá trị lớn/nhỏ khác nhau
    - Pandas tự infer dtype thường hợp lý hơn
    - Ép dtype sai có thể làm mất chính xác hoặc lỗi parse

    low_memory=False:
    - Pandas đọc file lớn đôi khi suy luận dtype không ổn định (đọc theo từng block)
    - low_memory=False giúp pandas cố gắng suy luận dtype nhất quán hơn (đổi lại tốn RAM hơn chút)
    """
    csv_path = Path(csv_path)
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)

    parquet_path = cache_dir / (csv_path.stem + "_continuous.parquet")

    # Đọc từ cache nếu có
    if use_cache and parquet_path.exists():
        t0 = time.time()
        df = pd.read_parquet(parquet_path)
        if logger:
            logger.info(f"[IO] Read parquet cache {parquet_path.name}: {time.time()-t0:.2f}s")
        return _lower_strip_columns(df)

    # Đọc CSV theo chunks (không set dtype, để pandas tự infer)
    if logger:
        logger.info(f"[IO] Reading CSV {csv_path.name} (no cache found)...")
    t0_csv = time.time()

    chunks = pd.read_csv(csv_path, chunksize=chunksize, low_memory=False)

    # Ghép các chunk lại
    df = pd.concat(chunks, ignore_index=True)
    df = _lower_strip_columns(df)

    if logger:
        logger.info(f"[IO] Read CSV {csv_path.name}: {time.time()-t0_csv:.2f}s rows={len(df):,}")

    # Luôn cache lại sau khi đọc xong
    t0_pq = time.time()
    df.to_parquet(parquet_path, index=False)
    if logger:
        logger.info(f"[IO] Saved parquet cache {parquet_path.name}: {time.time()-t0_pq:.2f}s")

    return df


def load_all_dfs(
    cfg: Config,
    logger: Optional[logging.Logger] = None
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Load 4 feature sets thành 4 DataFrame.

    Trả về:
    - dlls: DataFrame từ DLLs_Imported.csv
    - api:  DataFrame từ API_Functions.csv
    - hdr:  DataFrame từ PE_Header.csv
    - sect: DataFrame từ PE_Section.csv

    Lợi ích của việc tách riêng 4 DataFrame:
    - Bạn có thể chọn dùng từng phần hoặc merge chúng lại tuỳ pipeline
    - Dễ debug từng nhóm feature
    """
    data_dir = Path(cfg.data_dir)

    # Tạo đường dẫn tới từng file dựa trên config
    p_dlls = data_dir / cfg.dlls_csv
    p_api = data_dir / cfg.api_csv
    p_hdr = data_dir / cfg.hdr_csv
    p_sect = data_dir / cfg.sect_csv

    # Đọc từng file bằng hàm phù hợp
    dlls = read_binary_fast(
        p_dlls,
        cache_dir=cfg.cache_dir,
        use_cache=cfg.use_cache,
        chunksize=cfg.chunksize,
        logger=logger
    )
    api = read_binary_fast(
        p_api,
        cache_dir=cfg.cache_dir,
        use_cache=cfg.use_cache,
        chunksize=cfg.chunksize,
        logger=logger
    )
    hdr = read_continuous(
        p_hdr,
        cache_dir=cfg.cache_dir,
        use_cache=cfg.use_cache,
        chunksize=cfg.chunksize,
        logger=logger
    )
    sect = read_continuous(
        p_sect,
        cache_dir=cfg.cache_dir,
        use_cache=cfg.use_cache,
        chunksize=cfg.chunksize,
        logger=logger
    )

    return dlls, api, hdr, sect
