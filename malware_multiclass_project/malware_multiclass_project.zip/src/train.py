"""
run_train.py (hoặc train_entrypoint.py)

Đây là file “điều phối” (orchestrator) cho toàn bộ pipeline training:
1) Load dataset đã xử lý (sparse) nếu có -> nhanh
   Nếu chưa có -> load CSV thô -> build sparse matrix -> save cache
2) Encode nhãn (LabelEncoder)
3) Split train/val/test theo stratified (giữ tỉ lệ lớp)
4) Train các mô hình ứng viên (LogReg, LightGBM) và tune bằng VAL
5) Chọn mô hình tốt nhất theo metric trên VAL
6) (Quan trọng) Refit mô hình tốt nhất trên train+val
7) Đánh giá cuối cùng trên TEST (không dùng TEST để tune -> tránh leakage)
8) Lưu artifacts: model, metrics, meta, và explainability (top features / importance)

Từ góc nhìn người mới:
- File này giống như “main()” của dự án ML: gọi đúng thứ tự và đảm bảo không leakage.
"""

from __future__ import annotations

import json
from dataclasses import asdict  # NOTE: hiện chưa dùng trong file này (có thể bỏ nếu muốn sạch)
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple  # NOTE: Optional/Tuple có thể chưa dùng hết

import numpy as np
import scipy.sparse as sp  # NOTE: sp hiện chưa dùng trực tiếp (X là sparse nhưng slicing dùng numpy)
from sklearn.base import clone
from sklearn.preprocessing import LabelEncoder
import joblib

from .config import Config
from .io_data import load_all_dfs
from .build_features import build_sparse_Xy, load_processed, save_processed
from .split_data import stratified_train_val_test_split, assert_no_overlap, print_split_summary
from .utils import make_logger, set_global_seed, human_bytes, sparse_memory_bytes, dump_json, timer, column_type_summary_v2
from .evaluate import print_report, save_metrics_json
from .models import train_logreg_elasticnet, train_lgbm, train_lgbm_optuna, TrainResult


def _choose_best(results: List[TrainResult], metric: str, logger=None) -> TrainResult:
    """
    Chọn mô hình tốt nhất dựa trên metric trên tập validation.

    - results: danh sách TrainResult (mỗi TrainResult có val_metrics)
    - metric: tên metric dùng để so sánh (vd: "f1_macro", "accuracy", ...)
    - logger: ghi log

    Logic:
    - Lấy score = val_metrics[metric]
    - Nếu metric không có trong dict thì fallback sang f1_macro
    """
    assert results, "No model results to choose from."

    best = None
    best_score = -1e9

    for r in results:
        score = r.val_metrics.get(metric, r.val_metrics.get("f1_macro", -1e9))
        if logger:
            logger.info(f"[MODEL] {r.name} val_{metric}={score}")

        if score > best_score:
            best_score = score
            best = r

    assert best is not None
    if logger:
        logger.info(f"[MODEL] BEST = {best.name} ({metric}={best_score})")

    return best


def _refit_best_on_trainval(best: TrainResult, X_trainval, y_trainval, logger=None):
    """
    Refit (huấn luyện lại) mô hình tốt nhất trên train+val trước khi test.

    Vì sao phải refit?
    - Trong quá trình chọn model, ta train trên train và đánh giá trên val.
    - Sau khi đã chọn được best model/params, ta nên tận dụng cả train+val để model học nhiều dữ liệu hơn
      => thường giúp tăng chất lượng trước khi đánh giá TEST.

    Cực kỳ quan trọng:
    - Không dùng TEST ở bước refit này => tránh data leakage.
    - TEST chỉ dùng 1 lần cuối để báo cáo.
    """
    name = best.name

    # ========== Case 1: Logistic Regression (Pipeline) ==========
    if name.startswith("logreg"):
        # best.model là Pipeline đã được fit trên train.
        # clone(...) để tạo bản sao "chưa fit" nhưng giữ nguyên cấu hình,
        # rồi fit lại trên train+val.
        m = clone(best.model)
        m.fit(X_trainval, y_trainval)
        return m

    # ========== Case 2: LightGBM ==========
    # LightGBM có thể không có trong môi trường (tuỳ máy), nên import an toàn.
    try:
        import lightgbm as lgb  # noqa: F401
    except Exception:
        if logger:
            logger.warning("LightGBM missing when refit. Using already-fitted model.")
        return best.model

    # Nếu model có get_params() thì ta lấy params ra để tạo model mới và fit lại.
    if hasattr(best.model, "get_params"):
        params = best.model.get_params()

        # Nếu trong quá trình train có early stopping, best_iteration_ sẽ cho biết số cây tốt nhất.
        # Khi refit trên train+val, ta set n_estimators = best_iteration_ để tránh overfit.
        best_iter = getattr(best.model, "best_iteration_", None)
        if best_iter is not None:
            params["n_estimators"] = int(best_iter)

        # Tạo model mới cùng class với best.model, rồi fit lại.
        # (Không truyền eval_set/callbacks ở đây vì ta refit cuối cùng)
        m = best.model.__class__(**params)
        m.fit(X_trainval, y_trainval)
        return m

    # fallback: nếu không refit được theo cách trên thì trả lại model cũ
    return best.model


def export_logreg_top_features(
    pipe,
    feature_names: List[str],
    classes: List[str],
    out_path: Path,
    topk: int = 25,
    logger=None
) -> None:
    """
    Xuất (export) top features cho Logistic Regression dựa trên hệ số (coef).

    Ý tưởng:
    - Logistic Regression có hệ số w cho mỗi feature (mỗi lớp có 1 vector w).
    - w > 0: feature làm tăng xác suất thuộc lớp đó
    - w < 0: feature làm giảm xác suất thuộc lớp đó

    output:
    - Với mỗi lớp: top_positive và top_negative (topk feature lớn nhất/nhỏ nhất)

    Lưu ý:
    - Vì pipeline có VarianceThreshold (vt) nên một số feature bị loại.
      Ta phải dùng vt.get_support() để map lại đúng feature_names sau khi lọc.
    """
    try:
        vt = pipe.named_steps.get("vt", None)
        clf = pipe.named_steps.get("clf", None)

        # Nếu không có clf hoặc clf không có coef_ thì không export được
        if clf is None or not hasattr(clf, "coef_"):
            return

        # support: mask boolean chỉ ra feature nào được giữ lại sau VarianceThreshold
        support = None
        if vt is not None and hasattr(vt, "get_support"):
            support = vt.get_support()

        # Nếu không có vt thì coi như giữ toàn bộ feature
        if support is None:
            support = np.ones(len(feature_names), dtype=bool)

        feat_sel = np.array(feature_names)[support]
        coef = clf.coef_  # shape: (n_classes, n_features_selected)

        out = {}
        for ci, cname in enumerate(classes):
            w = coef[ci]

            # idx_pos: topk hệ số lớn nhất (tác động dương mạnh nhất)
            idx_pos = np.argsort(-w)[:topk]

            # idx_neg: topk hệ số nhỏ nhất (âm nhất)
            idx_neg = np.argsort(w)[:topk]

            out[cname] = {
                "top_positive": [(feat_sel[i], float(w[i])) for i in idx_pos],
                "top_negative": [(feat_sel[i], float(w[i])) for i in idx_neg],
            }

        out_path.parent.mkdir(parents=True, exist_ok=True)
        with out_path.open("w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=2)

        if logger:
            logger.info(f"Saved logreg top-features to: {out_path}")

            # In top features cho từng class ra log
            logger.info("=" * 60)
            logger.info("TOP POSITIVE FEATURES PER CLASS (LogReg coefficients)")
            logger.info("=" * 60)
            for cname in classes:
                if cname in out:
                    top_feats = out[cname]["top_positive"][:topk]
                    logger.info(f"\n[Class: {cname}]")
                    for rank, (feat, coef) in enumerate(top_feats, start=1):
                        logger.info(f"  {rank:>2}. {feat:<40} coef={coef:+.4f}")

    except Exception as e:
        if logger:
            logger.warning(f"export_logreg_top_features failed: {e}")


def export_lgbm_feature_importance(
    model,
    feature_names: List[str],
    out_path: Path,
    topk: int = 200,
    logger=None
) -> None:
    """
    Xuất feature importance của LightGBM.

    LightGBM cung cấp model.feature_importances_:
    - thường là số lần feature được dùng để split (hoặc gain tùy cấu hình)
    - giá trị càng lớn => feature càng “quan trọng” theo mô hình

    output:
    - list các dict: {"feature": ..., "importance": ...} (topk theo importance)
    """
    try:
        if not hasattr(model, "feature_importances_"):
            return

        imp = np.asarray(model.feature_importances_)
        feat = np.asarray(feature_names)
        order = np.argsort(-imp)[:topk]

        rows = [{"feature": feat[i], "importance": int(imp[i])} for i in order]

        out_path.parent.mkdir(parents=True, exist_ok=True)
        with out_path.open("w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False, indent=2)

        if logger:
            logger.info(f"Saved lgbm feature importance to: {out_path}")

            # In top features ra log (LightGBM importance là overall, không theo class)
            logger.info("=" * 60)
            logger.info("TOP FEATURES (LightGBM importance - split count)")
            logger.info("=" * 60)
            top_display = min(25, len(rows))  # Hiển thị tối đa 25 features
            for rank, row in enumerate(rows[:top_display], start=1):
                logger.info(f"  {rank:>2}. {row['feature']:<40} importance={row['importance']:>6}")

    except Exception as e:
        if logger:
            logger.warning(f"export_lgbm_feature_importance failed: {e}")


def export_lgbm_shap_importance(
    model,
    X_sample,
    feature_names: List[str],
    classes: List[str],
    out_path: Path,
    topk: int = 25,
    logger=None
) -> None:
    """
    Tính SHAP values cho LightGBM để có per-class feature importance.

    SHAP giải thích: "Feature X đóng góp bao nhiêu vào việc model dự đoán class Y?"

    Tham số:
    - model: LGBMClassifier đã fit
    - X_sample: Subset của X_test để tính SHAP (nên ~500-1000 samples cho tốc độ)
    - feature_names: Tên các features
    - classes: Tên các classes
    - out_path: Đường dẫn file JSON output
    - topk: Số features hiển thị cho mỗi class
    - logger: Logger để ghi log
    """
    try:
        import shap
    except ImportError:
        if logger:
            logger.warning("[SHAP] shap package not installed. Run: pip install shap")
        return

    try:
        if logger:
            logger.info(f"[SHAP] Computing SHAP values for {X_sample.shape[0]} samples...")

        # 1) Tạo SHAP explainer cho tree models
        explainer = shap.TreeExplainer(model)

        # 2) Tính SHAP values
        # Với multiclass: shap_values là list of arrays, mỗi array shape (n_samples, n_features)
        shap_values = explainer.shap_values(X_sample)

        # 3) Với mỗi class, tính mean |SHAP| để rank importance
        out = {}
        for ci, cname in enumerate(classes):
            # Mean absolute SHAP value cho mỗi feature (trên tất cả samples)
            mean_abs_shap = np.abs(shap_values[ci]).mean(axis=0)

            # Sort giảm dần
            order = np.argsort(-mean_abs_shap)[:topk]

            out[cname] = [
                {"feature": feature_names[i], "mean_shap": float(mean_abs_shap[i])}
                for i in order
            ]

        # 4) Lưu JSON
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with out_path.open("w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=2)

        # 5) Log ra console
        if logger:
            logger.info(f"[SHAP] Saved SHAP importance to: {out_path}")
            logger.info("=" * 60)
            logger.info("TOP FEATURES PER CLASS (LightGBM SHAP values)")
            logger.info("=" * 60)
            for cname in classes:
                logger.info(f"\n[Class: {cname}]")
                for rank, row in enumerate(out[cname][:topk], start=1):
                    logger.info(f"  {rank:>2}. {row['feature']:<40} SHAP={row['mean_shap']:.4f}")

    except Exception as e:
        if logger:
            logger.warning(f"[SHAP] SHAP analysis failed: {e}")


def run_training(cfg: Config) -> None:
    """
    Hàm chính chạy toàn bộ pipeline training.

    Nên đọc theo thứ tự bước 1..9 dưới đây để hiểu luồng:
    1) Setup folder + logger + seed
    2) Load processed dataset (nếu có) / nếu không có thì build từ CSV
    3) Encode labels
    4) Split train/val/test (stratified)
    5) Train candidates (tune trên VAL)
    6) Chọn best theo metric VAL
    7) Refit best trên train+val
    8) Evaluate trên TEST
    9) Save artifacts + explainability exports
    """
    # Tạo các thư mục outputs/cache cần thiết
    cfg.ensure_dirs()

    # run_id để phân biệt các lần chạy (log, model, report không bị ghi đè)
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")

    # log file: outputs/logs/train_YYYYMMDD_HHMMSS.log
    log_path = Path(cfg.out_dir) / "logs" / f"train_{run_id}.log"
    logger = make_logger("malware-train", log_path=log_path)

    logger.info("==== Malware Multiclass Training ====")
    logger.info(f"run_id = {run_id}")
    logger.info("Config:\n" + json.dumps(cfg.to_dict(), ensure_ascii=False, indent=2))

    # Cố định seed để kết quả reproducible (chia dữ liệu / random init)
    set_global_seed(cfg.random_state)

    # ==========================================================
    # 1) Load processed (sparse) dataset if exists
    # ==========================================================
    with timer(logger, "Load processed dataset (if exists)"):
        loaded = load_processed(cfg, logger=logger)

    if loaded is None:
        # Nếu chưa có cache processed (X sparse), ta phải đọc CSV thô và build X
        logger.info("No processed dataset found -> load raw CSVs and build sparse matrix.")

        # 1.1) Load 4 CSV -> 4 DataFrame
        with timer(logger, "Load raw CSVs -> DataFrames"):
            dlls, api, hdr, sect = load_all_dfs(cfg, logger=logger)
            logger.info(
                f"dlls shape={dlls.shape} api shape={api.shape} "
                f"hdr shape={hdr.shape} sect shape={sect.shape}"
            )

        if cfg.log_data_observation:
            logger.info("Column type summary (raw inputs):")
            column_type_summary_v2(
                dlls,
                "DLLs",
                logger=logger,
                max_listed=cfg.log_data_observation_max_cols,
            )
            column_type_summary_v2(
                api,
                "APIs",
                logger=logger,
                max_listed=cfg.log_data_observation_max_cols,
            )
            column_type_summary_v2(
                hdr,
                "Header",
                logger=logger,
                max_listed=cfg.log_data_observation_max_cols,
            )
            column_type_summary_v2(
                sect,
                "Section",
                logger=logger,
                max_listed=cfg.log_data_observation_max_cols,
            )

        # 1.2) Build sparse X + y (string) + sha + feature_names
        with timer(logger, "Build X (CSR) + y + sha + feature_names"):
            X, y_str, sha, feature_names = build_sparse_Xy(dlls, api, hdr, sect, logger=logger)

        # 1.2.5) Log compression ratio (để đưa vào báo cáo thesis)
        raw_size = sum([df.memory_usage().sum() for df in [dlls, api, hdr, sect]])
        sparse_size = sparse_memory_bytes(X)
        compression_ratio = raw_size / sparse_size if sparse_size > 0 else 0
        logger.info(
            f"[THESIS] Optimization achieved: Raw DataFrames ({human_bytes(raw_size)}) -> "
            f"Sparse Matrix ({human_bytes(sparse_size)}). "
            f"Ratio: {compression_ratio:.2f}x smaller."
        )

        # 1.3) Save processed để lần sau load nhanh (khỏi build lại)
        with timer(logger, "Save processed dataset"):
            save_processed(cfg, X, y_str, sha, feature_names, logger=logger)

        # giải phóng RAM (DataFrame rất nặng)
        del dlls, api, hdr, sect
    else:
        # Nếu đã có cache: load ra luôn
        X, y_str, sha, feature_names = loaded

    # ==========================================================
    # 2) Encode labels (string -> int)
    # ==========================================================
    # y_str trong dataset thường là "family name" hoặc label dạng string.
    # Model cần y dạng số nguyên 0..K-1 => dùng LabelEncoder.
    le = LabelEncoder()
    y = le.fit_transform(y_str.astype(str))

    # classes_ là danh sách tên lớp theo thứ tự mapping:
    # y==0 tương ứng classes[0], y==1 tương ứng classes[1], ...
    # Create valid mapping (int -> str)
    # Dữ liệu gốc đang là "0", "1"... cần ánh xạ sang tên người đọc hiểu
    LABEL_NAMES = {
        "0": "Benign",
        "1": "RedLineStealer",
        "2": "Downloader",
        "3": "RAT",
        "4": "BankingTrojan",
        "5": "SnakeKeyLogger",
        "6": "Spyware"
    }

    classes = [str(c) for c in le.classes_]
    # Thử dịch từ "0" -> "Benign", nếu không có trong từ điển thì giữ nguyên "0"
    mapping = {i: LABEL_NAMES.get(label, label) for i, label in enumerate(classes)}

    logger.info(f"Label Mapping (ID -> Name): {mapping}")

    # lưu mapping để đọc lại khi inference / report
    dump_json(Path(cfg.out_dir) / "reports" / f"classes_{run_id}.json", mapping)

    # ==========================================================
    # 3) Split train/val/test (stratified)
    # ==========================================================
    # NOTE rất quan trọng: val_size trong stratified_train_val_test_split
    # đang được định nghĩa là tỉ lệ trên TOÀN BỘ dataset.
    # Bạn phải đảm bảo cfg.val_size cũng theo định nghĩa này, nếu không sẽ chia sai tỉ lệ.
    split = stratified_train_val_test_split(
        y_int=y,
        test_size=cfg.test_size,
        val_size=cfg.val_size,
        random_state=cfg.random_state,
    )

    # Kiểm tra không có SHA256 trùng giữa các split (ngăn leakage)
    assert_no_overlap(sha, split)

    # In ra số lượng + phân bố lớp ở TRAIN/VAL/TEST để kiểm tra stratify
    print_split_summary(y, split, classes, logger=logger)

    # Lấy ra X/y theo index split
    X_train = X[split.train_idx]
    y_train = y[split.train_idx]
    X_val = X[split.val_idx]
    y_val = y[split.val_idx]
    X_test = X[split.test_idx]
    y_test = y[split.test_idx]

    # Log thông tin sparse:
    # - shape: (n_samples, n_features)
    # - nnz: số phần tử khác 0 (non-zeros)
    # - mem: ước lượng bộ nhớ của sparse matrix
    logger.info(f"X_train={X_train.shape} nnz={X_train.nnz:,} mem={human_bytes(sparse_memory_bytes(X_train))}")
    logger.info(f"X_val  ={X_val.shape} nnz={X_val.nnz:,} mem={human_bytes(sparse_memory_bytes(X_val))}")
    logger.info(f"X_test ={X_test.shape} nnz={X_test.nnz:,} mem={human_bytes(sparse_memory_bytes(X_test))}")

    # ==========================================================
    # 4) Train candidates (tune on VAL)
    # ==========================================================
    results: List[TrainResult] = []

    # 4.1) Logistic Regression grid search (chọn best theo VAL)
    if cfg.use_logreg:
        with timer(logger, "Train LogReg (grid)"):
            r_logreg = train_logreg_elasticnet(X_train, y_train, X_val, y_val, cfg, logger=logger)
            results.append(r_logreg)
    else:
        logger.info("[LogReg] Skipped (use_logreg=False in config)")

    # 4.2) LightGBM (baseline hoặc tune bằng Optuna)
    if cfg.use_lightgbm:
        if cfg.lgbm_tune:
            with timer(logger, "Train LightGBM (Optuna tune)"):
                r_lgbm = train_lgbm_optuna(X_train, y_train, X_val, y_val, cfg, logger=logger)
        else:
            with timer(logger, "Train LightGBM (baseline)"):
                r_lgbm = train_lgbm(X_train, y_train, X_val, y_val, cfg, logger=logger)

        if r_lgbm is not None:
            results.append(r_lgbm)

    # ==========================================================
    # 5) Select best by metric on VAL
    # ==========================================================
    best = _choose_best(results, cfg.metric_for_model_select, logger=logger)

    # ==========================================================
    # 6) Evaluate BEST on VAL with detailed report
    # ==========================================================
    y_val_pred = best.model.predict(X_val)

    # predict_proba dùng để tính log_loss (nếu model hỗ trợ)
    y_val_proba = None
    if hasattr(best.model, "predict_proba"):
        try:
            y_val_proba = best.model.predict_proba(X_val)
        except Exception:
            y_val_proba = None

    # print_report sẽ log:
    # - metrics dict
    # - classification_report
    # - confusion matrix (count + normalized)
    val_metrics = print_report(
        y_val, y_val_pred, classes,
        title=f"VAL ({best.name})",
        logger=logger,
        y_proba=y_val_proba
    )

    # ==========================================================
    # 7) Refit best model on train+val, then evaluate on TEST
    # ==========================================================
    # Gộp train_idx và val_idx -> trainval
    idx_trainval = np.concatenate([split.train_idx, split.val_idx])
    X_trainval = X[idx_trainval]
    y_trainval = y[idx_trainval]

    with timer(logger, f"Refit BEST ({best.name}) on train+val"):
        best_refit = _refit_best_on_trainval(best, X_trainval, y_trainval, logger=logger)

    # TEST evaluation: chỉ làm sau khi đã chọn model xong, tránh leakage
    y_test_pred = best_refit.predict(X_test)
    y_test_proba = None
    if hasattr(best_refit, "predict_proba"):
        try:
            y_test_proba = best_refit.predict_proba(X_test)
        except Exception:
            y_test_proba = None

    test_metrics = print_report(
        y_test, y_test_pred, classes,
        title=f"TEST ({best.name})",
        logger=logger,
        y_proba=y_test_proba
    )

    # ==========================================================
    # 8) Save artifacts (model + reports)
    # ==========================================================
    model_path = Path(cfg.out_dir) / "models" / f"model_{best.name}_{run_id}.joblib"
    report_path = Path(cfg.out_dir) / "reports" / f"metrics_{best.name}_{run_id}.json"
    meta_path = Path(cfg.out_dir) / "reports" / f"meta_{best.name}_{run_id}.json"

    # joblib.dump: lưu object Python (model, metadata...) để load lại dùng inference.
    # compress=3: nén vừa phải để tiết kiệm dung lượng.
    joblib.dump(
        {
            "model": best_refit,
            "label_encoder_classes": classes,
            # feature_names_path: đường dẫn tới file tên feature (để mapping khi explain/inference)
            "feature_names_path": str((Path(cfg.data_dir) / cfg.processed_dirname / cfg.processed_feat_name)),
            "run_id": run_id,
            "best_name": best.name,
            "best_params": best.best_params,
            "val_metrics": val_metrics,
            "test_metrics": test_metrics,
            "config": cfg.to_dict(),
        },
        model_path,
        compress=3,
    )

    # Lưu metrics ra JSON (dễ đọc, dễ đưa vào report)
    save_metrics_json(report_path, {"val": val_metrics, "test": test_metrics, "best_params": best.best_params})

    # meta file: thông tin ngắn gọn để tra nhanh
    dump_json(meta_path, {"run_id": run_id, "best": best.name, "model_path": str(model_path)})

    logger.info(f"Saved model: {model_path}")
    logger.info(f"Saved report: {report_path}")

    # ==========================================================
    # 9) Explainability exports (giải thích mô hình)
    # ==========================================================
    # Nếu best là logreg -> xuất top features theo coef
    if best.name.startswith("logreg"):
        export_logreg_top_features(
            best_refit,
            feature_names=feature_names,
            classes=classes,
            out_path=Path(cfg.out_dir) / "reports" / f"top_features_logreg_{run_id}.json",
            topk=25,
            logger=logger,
        )

    # Nếu best là lgbm -> xuất feature importance
    if best.name.startswith("lgbm"):
        export_lgbm_feature_importance(
            best_refit,
            feature_names=feature_names,
            out_path=Path(cfg.out_dir) / "reports" / f"feature_importance_lgbm_{run_id}.json",
            topk=300,
            logger=logger,
        )

        # SHAP analysis cho per-class importance (dùng sample để tính nhanh)
        sample_size = min(1000, X_test.shape[0])
        export_lgbm_shap_importance(
            best_refit,
            X_sample=X_test[:sample_size],
            feature_names=feature_names,
            classes=classes,
            out_path=Path(cfg.out_dir) / "reports" / f"shap_importance_lgbm_{run_id}.json",
            topk=25,
            logger=logger,
        )

    logger.info("==== DONE ====")


if __name__ == "__main__":
    # Cho phép chạy file này trực tiếp:
    # python -m your_package.run_train  (tuỳ cấu trúc project)
    cfg = Config()
    run_training(cfg)
