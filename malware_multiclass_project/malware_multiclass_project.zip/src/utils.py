"""
utils.py

File tiện ích (utility) dùng chung cho toàn dự án.

Nó chứa các hàm nhỏ nhưng rất hay dùng trong pipeline ML:
- set_global_seed: cố định seed để kết quả reproducible
- human_bytes / df_memory_bytes / sparse_memory_bytes: ước lượng bộ nhớ dễ đọc
- make_logger: tạo logger vừa in console vừa ghi file log
- timer: đo thời gian chạy một đoạn code (context manager)
- dump_json: lưu object ra JSON
- pretty_print_class_distribution: in phân bố lớp (tỉ lệ nhãn) để kiểm tra dữ liệu/split

Mục tiêu:
- Không lặp code ở nhiều file
- Dễ đọc và dễ bảo trì
"""

from __future__ import annotations

import json
import logging
import os
import random
import time
from contextlib import contextmanager
from dataclasses import asdict  # NOTE: hiện chưa dùng trong đoạn này (có thể bỏ)
from pathlib import Path
from typing import Any, Dict, Optional, List

import numpy as np
import pandas as pd
import scipy.sparse as sp


def set_global_seed(seed: int) -> None:
    """
    Cố gắng làm reproducible (tái lập kết quả khi chạy lại).

    "Reproducible" nghĩa là:
    - Bạn chạy lại notebook/script nhiều lần mà kết quả (chia dữ liệu, random init...) giống nhau
    - Rất quan trọng trong nghiên cứu/thesis để người khác có thể tái lập thí nghiệm

    Hàm này cố định 3 nguồn random phổ biến:
    1) PYTHONHASHSEED: ảnh hưởng đến thứ tự hash (vd Aset/dict) trong Python
    2) random.seed: random module của Python
    3) np.random.seed: random của NumPy

    Lưu ý:
    - Một số thuật toán / môi trường (GPU, multi-thread) vẫn có thể không 100% reproducible,
      nhưng đây là bước nền tảng tốt.
    """
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)


def human_bytes(n: int) -> str:
    """
    Convert số byte (vd 123456789) -> chuỗi dễ đọc (vd '117.74 MB').

    Ví dụ:
    - human_bytes(1024)       -> '1.00 KB'
    - human_bytes(10_485_760) -> '10.00 MB'

    Tại sao cần?
    - Khi log bộ nhớ của DataFrame / sparse matrix, đọc byte rất khó hình dung.
    """
    units = ["B", "KB", "MB", "GB", "TB"]
    x = float(n)
    for u in units:
        if x < 1024 or u == units[-1]:
            return f"{x:,.2f} {u}"
        x /= 1024.0
    return f"{x:,.2f} TB"  # fallback (thực tế khó tới đây)


def df_memory_bytes(df: pd.DataFrame) -> int:
    """
    Ước lượng bộ nhớ DataFrame đang chiếm (bytes).

    df.memory_usage(deep=True):
    - deep=True tính sâu hơn cho object/string (thường chính xác hơn)
    """
    return int(df.memory_usage(deep=True).sum())


def sparse_memory_bytes(X: sp.spmatrix) -> int:
    """
    Ước lượng bộ nhớ của sparse matrix (CSR/CSC).

    Với CSR/CSC, dữ liệu được lưu bởi 3 mảng chính:
    - data: các giá trị khác 0
    - indices: cột tương ứng của mỗi giá trị
    - indptr: con trỏ chỉ bắt đầu/kết thúc mỗi hàng (CSR) hoặc mỗi cột (CSC)

    Tổng bộ nhớ ~ data.nbytes + indices.nbytes + indptr.nbytes

    Lý do cần:
    - Dữ liệu malware kiểu bag-of-words rất sparse -> phải theo dõi xem X có quá nặng không.
    """
    total = 0
    for attr in ("data", "indices", "indptr"):
        if hasattr(X, attr):
            total += getattr(X, attr).nbytes
    return int(total)


def make_logger(name: str, log_path: Optional[Path] = None, level=logging.INFO) -> logging.Logger:
    """
    Tạo logger vừa in ra console, vừa ghi file (nếu có log_path).

    Vì sao dùng logger thay vì print?
    - Logger có mức độ (INFO/WARNING/ERROR)
    - Ghi được ra file log (để debug và lưu lại lịch sử thí nghiệm)
    - Format thời gian rõ ràng

    Tham số:
    - name: tên logger (vd 'malware-train')
    - log_path: nếu cung cấp, sẽ ghi log ra file tại đường dẫn này
    - level: mức log (mặc định INFO)
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # propagate=False để tránh log bị in trùng do logger cha cũng in
    logger.propagate = False

    # Tránh add handler nhiều lần (đặc biệt khi rerun cell trong notebook)
    # Nếu không check, mỗi lần chạy lại sẽ add thêm handler -> log bị lặp nhiều lần.
    if logger.handlers:
        return logger

    # format log: [2026-01-07 12:00:00] INFO - message
    fmt = logging.Formatter("[%(asctime)s] %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S")

    # Handler 1: stream ra console
    ch = logging.StreamHandler()
    ch.setLevel(level)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    # Handler 2: ghi ra file (nếu cần)
    if log_path is not None:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(log_path, mode="w", encoding="utf-8")
        fh.setLevel(level)
        fh.setFormatter(fmt)
        logger.addHandler(fh)

    return logger


@contextmanager
def timer(logger: Optional[logging.Logger], name: str):
    """
    Context manager để đo thời gian chạy một khối lệnh.

    Cách dùng:
        with timer(logger, "Load data"):
            ... code load data ...

    Khi thoát khỏi block, nó sẽ log:
        [TIMER] Load data: 1.23s

    Ý nghĩa:
    - Biết bước nào tốn thời gian nhất để tối ưu (đọc CSV? build features? train?)
    """
    t0 = time.time()
    yield
    t1 = time.time()
    if logger:
        logger.info(f"[TIMER] {name}: {t1 - t0:.2f}s")


def dump_json(path: Path, obj: Any) -> None:
    """
    Lưu object Python ra file JSON.

    - path.parent.mkdir(...): tự tạo folder nếu chưa tồn tại
    - ensure_ascii=False: giữ tiếng Việt
    - indent=2: format đẹp để đọc

    Thường dùng để lưu:
    - classes mapping
    - metrics
    - config
    - meta của run
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def pretty_print_class_distribution(y: np.ndarray, classes: Optional[list] = None) -> str:
    """
    Trả về chuỗi thống kê phân bố nhãn (class distribution).

    Tham số:
    - y: mảng nhãn (có thể là int hoặc string)
    - classes: (tuỳ chọn) list mapping nếu y là int.
      Ví dụ:
        y = [0, 0, 1, 2]
        classes = ["benign", "trojan", "worm"]
      Khi đó 0 sẽ được in thành "benign" thay vì "0".

    Output dạng:
        - benign:  1000 (70.00%)
        - trojan:   300 (21.00%)
        - worm:     130 ( 9.00%)

    Dùng để:
    - kiểm tra dataset có lệch lớp không
    - kiểm tra stratified split có giữ đúng tỉ lệ lớp không
    """
    unique, counts = np.unique(y, return_counts=True)
    total = counts.sum()

    lines = []
    for u, c in zip(unique, counts):
        # name mặc định là chính u
        name = str(u)

        # Nếu có classes, thử map u -> classes[int(u)]
        if classes is not None:
            try:
                name = str(classes[int(u)])
            except Exception:
                # nếu u không convert được sang int hoặc index lỗi, giữ nguyên name
                pass

        # c/total: tỷ lệ của lớp đó
        lines.append(f"  - {name:>20}: {c:>7} ({c/total:>6.2%})")

    return "\n".join(lines)


_TRUE_SET = {"true", "t", "yes", "y", "1"}
_FALSE_SET = {"false", "f", "no", "n", "0"}


def _is_binary_series(s: pd.Series) -> bool:
    """Return True if the non-null values look binary (0/1 or true/false)."""
    s = s.dropna()
    if s.empty:
        return False

    if pd.api.types.is_bool_dtype(s):
        return True

    if pd.api.types.is_numeric_dtype(s):
        u = pd.unique(s)
        try:
            u = np.asarray(u)
        except Exception:
            return False
        return np.isin(u, [0, 1]).all()

    ss = s.astype(str).str.strip().str.lower()
    u = set(pd.unique(ss))
    return u.issubset(_TRUE_SET.union(_FALSE_SET))


def _looks_numeric(s: pd.Series, min_ratio: float = 0.99) -> bool:
    """Heuristic: True if most non-null values coerce to numeric."""
    s_nonnull = s.dropna()
    if s_nonnull.empty:
        return False
    coerced = pd.to_numeric(s_nonnull, errors="coerce")
    ok_ratio = coerced.notna().mean()
    return ok_ratio >= min_ratio


def column_type_summary_v2(
    df: pd.DataFrame,
    name: str,
    ignore_cols: tuple = ("sha256", "type"),
    discrete_unique_max: int = 20,
    continuous_unique_ratio_min: float = 0.05,
    logger: Optional[logging.Logger] = None,
    max_listed: int = 6,
) -> Dict[str, List[str]]:
    """
    Group columns by simple heuristics (binary, numeric discrete/continuous, etc.)
    and log a compact summary. Returns the grouped columns.
    """
    ignore_cols = {c.lower() for c in ignore_cols}

    groups: Dict[str, List[str]] = {
        "binary": [],
        "numeric_continuous": [],
        "numeric_discrete": [],
        "categorical": [],
        "constant": [],
        "all_missing": [],
        "ignored": [],
    }

    n_rows = len(df)

    for col in df.columns:
        if col.lower() in ignore_cols:
            groups["ignored"].append(col)
            continue

        s = df[col]

        if s.isna().all():
            groups["all_missing"].append(col)
            continue

        nunique = s.nunique(dropna=True)
        if nunique <= 1:
            groups["constant"].append(col)
            continue

        if _is_binary_series(s):
            groups["binary"].append(col)
            continue

        if pd.api.types.is_numeric_dtype(s) or _looks_numeric(s):
            sn = pd.to_numeric(s, errors="coerce")
            nunique_num = sn.nunique(dropna=True)
            unique_ratio = nunique_num / max(1, sn.notna().sum())
            if nunique_num <= discrete_unique_max or unique_ratio < continuous_unique_ratio_min:
                groups["numeric_discrete"].append(col)
            else:
                groups["numeric_continuous"].append(col)
        else:
            groups["categorical"].append(col)

    feature_cols = [c for c in df.columns if c.lower() not in ignore_cols]
    ignore_list = sorted(ignore_cols)
    mem = human_bytes(df_memory_bytes(df))

    lines = [
        f"--- {name} ---",
        f"Rows: {n_rows:,}",
        f"Total columns: {len(df.columns)}",
        f"Feature columns (excluding {ignore_list}): {len(feature_cols)}",
        f"Memory: {mem}",
        "",
    ]

    key_order = [
        "binary",
        "numeric_continuous",
        "numeric_discrete",
        "categorical",
        "constant",
        "all_missing",
        "ignored",
    ]
    for k in key_order:
        lines.append(f"{k:>18}: {len(groups[k])}")

    def _emit(msg: str) -> None:
        if logger:
            logger.info(msg)
        else:
            print(msg)

    for line in lines:
        _emit(line)

    if max_listed > 0:
        for k in key_order:
            cols = groups[k]
            if not cols:
                continue
            sample = cols[:max_listed]
            more = ""
            if len(cols) > max_listed:
                more = f"... (+{len(cols) - max_listed} more)"
            _emit(f"{name} {k} sample: {', '.join(sample)}{more}")

    return groups
