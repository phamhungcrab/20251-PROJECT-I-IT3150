"""
split.py

File này lo việc chia dữ liệu thành 3 phần:
- Train: dùng để "fit" (học mô hình)
- Validation (Val): dùng để chọn tham số / chọn mô hình (model selection)
- Test: chỉ dùng để báo cáo kết quả cuối cùng (không đụng vào lúc tune)

Điểm quan trọng với dữ liệu malware:
- Phải tránh "data leakage" (rò rỉ dữ liệu), ví dụ:
  - cùng một mẫu (SHA256) xuất hiện ở cả train và test
  - hoặc chia dữ liệu dựa trên feature làm lộ thông tin nhãn
- Do đó split chỉ dựa trên y (nhãn) và index, không dùng feature.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple  # Tuple hiện chưa dùng trực tiếp trong code này (có thể bỏ)

import numpy as np
from sklearn.model_selection import train_test_split
# train_test_split: hàm chuẩn của sklearn để chia dữ liệu ngẫu nhiên.
# có tham số stratify giúp giữ tỉ lệ lớp giống nhau ở các tập.

from .utils import pretty_print_class_distribution
# pretty_print_class_distribution: hàm phụ in phân bố lớp (mỗi lớp bao nhiêu mẫu)
# để bạn kiểm tra split có giữ cân bằng theo lớp hay không.


# ==========================================================
# 1) Dataclass chứa kết quả split (chỉ số index)
# ==========================================================

@dataclass
class SplitIdx:
    """
    Lưu index của từng split:
    - train_idx: các vị trí (index) thuộc tập train
    - val_idx:   các vị trí thuộc tập validation
    - test_idx:  các vị trí thuộc tập test

    Lý do chỉ lưu index thay vì lưu luôn dữ liệu:
    - linh hoạt: bạn có thể áp index này cho X, y, sha256...
    - tránh copy data: tiết kiệm RAM
    """
    train_idx: np.ndarray
    val_idx: np.ndarray
    test_idx: np.ndarray


# ==========================================================
# 2) Hàm split stratified train/val/test
# ==========================================================

def stratified_train_val_test_split(
    y_int: np.ndarray,
    test_size: float,
    val_size: float,
    random_state: int,
):
    """
    Chia dataset thành train/val/test theo kiểu stratified (giữ tỉ lệ lớp).

    Khái niệm "stratified":
    - Nếu lớp A chiếm 70%, lớp B chiếm 30% trong toàn bộ dữ liệu,
      thì train/val/test cũng sẽ xấp xỉ 70/30.
    - Điều này quan trọng khi dữ liệu lệch lớp (malware family hiếm).

    Chỉ split dựa trên y (nhãn) + index, KHÔNG dùng feature:
    - Tránh leakage (ví dụ lỡ dùng feature có liên quan trực tiếp đến nhãn)

    Tham số:
    - y_int: nhãn dạng số nguyên (0..K-1), length = N samples
    - test_size: tỉ lệ test trên toàn bộ dataset (vd 0.2)
    - val_size:  tỉ lệ validation trên toàn bộ dataset (vd 0.2)
    - random_state: seed để chia reproducible

    Lưu ý quan trọng:
    - Ở đây val_size được định nghĩa là tỉ lệ của toàn bộ dataset.
      (Ví dụ val_size=0.2 nghĩa là val chiếm 20% toàn bộ.)
    """

    # kiểm tra điều kiện hợp lệ của các tỉ lệ
    assert 0 < test_size < 1
    assert 0 < val_size < 1
    assert test_size + val_size < 1, "test_size + val_size phải < 1"

    # idx_all = [0, 1, 2, ..., N-1]
    # Ta split dựa trên index thay vì split trực tiếp X để:
    # - dễ dùng lại cho nhiều ma trận feature khác nhau
    idx_all = np.arange(len(y_int))

    # ----------------------------------------------------------
    # BƯỚC 1: tách test khỏi toàn bộ
    #
    # idx_trainval: index còn lại (train + val)
    # idx_test: index của test set
    #
    # stratify=y_int: giữ tỉ lệ lớp theo y
    # ----------------------------------------------------------
    idx_trainval, idx_test = train_test_split(
        idx_all,
        test_size=test_size,
        random_state=random_state,
        stratify=y_int,
    )

    # ----------------------------------------------------------
    # BƯỚC 2: tách validation từ phần trainval
    #
    # Vì val_size được định nghĩa theo "toàn bộ dataset",
    # nên khi chỉ còn trainval = (1 - test_size),
    # ta phải quy đổi val_size sang tỉ lệ tương đối trên trainval:
    #
    # val_rel = val_size / (1 - test_size)
    #
    # Ví dụ:
    #   test_size = 0.2  -> trainval = 0.8
    #   val_size  = 0.2  -> val muốn là 20% toàn bộ
    #   val_rel   = 0.2 / 0.8 = 0.25
    #
    # Nghĩa là: lấy 25% của trainval làm validation,
    # để validation cuối cùng đúng 20% toàn bộ.
    # ----------------------------------------------------------
    val_rel = val_size / (1.0 - test_size)

    idx_train, idx_val = train_test_split(
        idx_trainval,
        test_size=val_rel,
        random_state=random_state,
        # stratify phải dựa trên y của đúng subset idx_trainval
        stratify=y_int[idx_trainval],
    )

    # Trả về object SplitIdx để dùng lại
    return SplitIdx(train_idx=idx_train, val_idx=idx_val, test_idx=idx_test)


# ==========================================================
# 3) Kiểm tra không trùng SHA256 giữa các split
# ==========================================================

def assert_no_overlap(sha: np.ndarray, split: SplitIdx) -> None:
    """
    Bảo đảm không có sha256 xuất hiện ở nhiều split (ngăn leakage).

    Vì sao cần?
    - SHA256 đại diện cho "mẫu file" cụ thể.
    - Nếu cùng 1 SHA xuất hiện ở train và test:
      mô hình có thể "nhớ" mẫu đó -> metric test sẽ bị ảo (leakage).

    Cách làm:
    - tạo set SHA của từng split
    - kiểm tra giao (intersection) giữa các set phải rỗng
    """

    # Lấy SHA theo index, rồi convert sang set để so giao nhanh
    s_tr = set(sha[split.train_idx].tolist())
    s_va = set(sha[split.val_idx].tolist())
    s_te = set(sha[split.test_idx].tolist())

    # intersection: phần tử chung giữa 2 tập hợp
    inter_tv = s_tr & s_va  # train ∩ val
    inter_tt = s_tr & s_te  # train ∩ test
    inter_vt = s_va & s_te  # val ∩ test

    # Nếu có trùng thì raise AssertionError -> báo leakage rõ ràng
    assert len(inter_tv) == 0, f"Leakage! train∩val has {len(inter_tv)} sha256 overlap"
    assert len(inter_tt) == 0, f"Leakage! train∩test has {len(inter_tt)} sha256 overlap"
    assert len(inter_vt) == 0, f"Leakage! val∩test has {len(inter_vt)} sha256 overlap"


# ==========================================================
# 4) In tóm tắt split (số lượng + phân bố lớp)
# ==========================================================

def print_split_summary(y_int: np.ndarray, split: SplitIdx, classes: list, logger=None) -> None:
    """
    In tóm tắt cho từng split:
    - n = số lượng mẫu
    - phân bố lớp (mỗi lớp bao nhiêu mẫu)

    Mục đích:
    - kiểm tra stratify có hoạt động không
    - tránh trường hợp một lớp hiếm bị rơi hết vào train hoặc bị mất khỏi val/test
    """

    def _log(title: str, idx: np.ndarray):
        if logger:
            logger.info(f"{title}: n={len(idx):,}")
            logger.info(pretty_print_class_distribution(y_int[idx], classes))

    _log("TRAIN", split.train_idx)
    _log("VAL", split.val_idx)
    _log("TEST", split.test_idx)
